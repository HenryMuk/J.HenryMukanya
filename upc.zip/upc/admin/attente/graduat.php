<?php
session_start();
require('../../actions/verifications/verifAttGrad.php');

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ntumba University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="../../../site_web/Images/logo.png" rel="icon">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }

        #sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            background-color: #343a40;
            padding-top: 20px;
            overflow-x: hidden;
        }

        #sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: #dee2e6;
            display: block;
            transition: 0.3s;
        }

        #sidebar a:hover {
            background-color: #495057;
            color: white;
        }

        #sidebar i {
            margin-right: 10px;
        }

        #content {
            margin-left: 250px;
            padding: 16px;
        }

        .page-title {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .card {
            background-color: white;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.1);
        }

        .card-body {
            padding: 20px;
            text-align: center;
        }

        .card-title {
            font-size: 18px;
            margin-top: 15px;
            color: #495057;
        }

        .school-logo {
            width: 50px;
            height: auto;
            margin-bottom: 10px;
        }

        .fa-home, .fa-sign-out-alt {
            font-size: 20px;
        }

        @media only screen and (max-width: 768px) {
            body {
                display: none; 
            }
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2; 
        }

        form {
            display: flex;
            align-items: center;
        }

        select {
            margin-right: 10px;
        }

        .navbar {
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .navbar-brand {
            margin-right: 20px;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        tbody tr {
            animation: fadeIn 0.5s ease-in-out;
        }

        .btn i {
            margin-right: 5px;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        tbody tr {
            animation: fadeIn 0.5s ease-in-out;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            white-space: nowrap;
        }
    </style>
</head>
<body>

    <div id="sidebar">
        <a href="../index.php" style="background-color: #495057;"><i class="fas fa-arrow-left"></i> Retour</a>
    </div>

    <div id="content">
        <h1 class="page-title">Graduat </h1>
        
       <br>
       
                <?php
                    while($approuves = $verification->fetch()){
                        
                        if($approuves['relever'] != NULL)
                        {
                            $visibilite = true;
                        }
                       
                        
                      
                ?>
            <div class="table-responsive">
                
            <label for="" class="form-control" style="font-size:18px; font-weight:bold;">IDENTITE DU CANDIDAT</label>
            <label for="" class="form-control">Nom : <?=$approuves['nom'];?></label>
            <label for="" class="form-control">Post-nom : <?=$approuves['postnom'];?></label>
            <label for="" class="form-control">Prenom : <?=$approuves['prenom'];?></label>
            <label for="" class="form-control">Téléphone :<?=$approuves['telephone'];?></label>
            <label for="" class="form-control">Adresse-mail : <?=$approuves['email'];?></label>
            <label for="" class="form-control">Genre : <?=$approuves['genre'];?></label>
            <label for="" class="form-control">Nationalité : <?=$approuves['nationalite'];?></label>
            <label for="" class="form-control">Date de naissance : <?=$approuves['date_naissance'];?></label>
            <label for="" class="form-control">Lieu de naissance : <?=$approuves['lieu_naissance'];?></label><br>

            <label for="" class="form-control">Commune : <?=$approuves['commune'];?></label>
            <label for="" class="form-control">Qartier : <?=$approuves['quartier'];?></label>
            <label for="" class="form-control">Avenue :<?=$approuves['avenue'];?></label>
            <label for="" class="form-control">Numero : <?=$approuves['numero'];?></label><br>

            <label for="" class="form-control" style="font-size:18px; font-weight:bold;">DOCUMENTS FOURNIS PAR LE CANDIDAT</label>
            <label for="" class="form-control">Diplôme de 5e Humanité : <a href="../../systeme/fichiers/<?=$approuves['diplome5'];?>">Telecharger le bulletin de 5e Humanité</a></label>
            <label for="" class="form-control">Diplôme de 6e Humanité : <a href="../../systeme/fichiers/<?=$approuves['diplome6'];?>">Telecharger le bulletin de 6e Humanité </a></label>
            <label for="" class="form-control">Attestation de réussite d'études secondaires(Baccalauréat) : <a href="../../systeme/fichiers/<?=$approuves['bac'];?>">Telecharger l'attestation de réussite d'études secondaires(Baccalauréat)</a></label>
            <label for="" class="form-control">Lettre de motivation : <a href="../../systeme/fichiers/<?=$approuves['motivation'];?>">Telecharger la lettre de motivation</a></label>
            
            <?php if(isset($visibilite)){ ?>
                <label for="" class="form-control">Relevé de côtes : <a href="../../systeme/fichiers/<?=$approuves['relever'];?>" > Telecharger le relevé de côtes</a></label><br>

            <?php } ?>

          
            
            <label for="" class="form-control" style="font-size:18px; font-weight:bold;">INSCRIPTION SOUHAITEE PAR LE CANDIDAT</label>
            <label for="" class="form-control">Promotion choisie : <?=$approuves['promotion'];?></label>
            <label for="" class="form-control">Faculté choisie : <?=$approuves['faculte'];?></label><br>
            
            <label for="" class="form-control" style="font-size:18px; font-weight:bold;">IDENTITE SUR LA PERSONNE DE CONFIANCE DU CANDIDAT</label>
            <label for="" class="form-control">Nom : <?=$approuves['nom_responsable'];?></label>
            <label for="" class="form-control">Post-nom : <?=$approuves['postnom_responsable'];?></label>
            <label for="" class="form-control">Prenom : <?=$approuves['prenom_responsable'];?></label>
            <label for="" class="form-control">Téléphone : <?=$approuves['telephone_responsable'];?></label><br>
            
            <label for="" class="form-control" style="font-size:18px; font-weight:bold;">DECISION</label>
            <label for="" class="form-control">Code d'inscription : <?=$approuves['code'];?></label>
            <label for="" class="form-control">Statut : <?=$approuves['statutt'];?></label>

            <a class="btn btn-success" href="../../actions/decisions/accepte_graduat.php?id=<?=$approuves['id']?>"><i class="fas fa-times"></i> Accepter l'inscription</a>

            <a class="btn btn-danger" href="../../actions/decisions/refuse_graduat.php?id=<?=$approuves['id']?>"><i class="fas fa-times"></i> Refuser l'inscription</a>
            <br><br><br><br>
            </div>
            <?php
                    }
            ?>


    </div>


</body>
</html>
