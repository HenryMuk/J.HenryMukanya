<?php
require('../actions/admin/verif.php');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="../../site_web/Images/logo.png" rel="icon">
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: white;
            font-family: 'Roboto', sans-serif;
        }

        .container {
            background-color: white;
            border-radius: 10px;
            padding: 40px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            animation: fadeIn 1s ease;
        }

        h1 {
            text-align: center;
            font-size: 25px;
            margin-bottom: 30px;
        }

        .form-group label {
            font-weight: bold;
            color: #333;
        }

        .form-group i {
            margin-right: 5px;
        }

        .form-control {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            font-size: 16px;
        }

        .btn-danger {
            color: #fff;
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border-radius: 5px;
            background: rgb(184, 26, 26);
        }

        .alert {
            margin-top: 20px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logo {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background-color: #fff;
            padding: 10px;
            display: inline-block;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0% {
                transform: translatey(0px);
            }
            50% {
                transform: translatey(-10px);
            }
            100% {
                transform: translatey(0px);
            }
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media only screen and (max-width: 768px) {
            body {
                display: none; 
            }
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        
        <form method="POST" id="loginForm">
            <input type="hidden" name="csrf_token" value="<?php echo $token; ?>">
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    </div>
                    <input type="text" class="form-control" id="nom" placeholder="Nom d'utilisateur" name="username" >
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    </div>
                    <input type="password" class="form-control" id="code" name="code" placeholder="Code d'authentification">
                </div>
            </div>
            <button type="submit" class="btn btn-danger" name="validate"><i class="fas fa-sign-in-alt"></i> Connexion</button>
        </form>
        
        <?php if (isset($error)) : ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>
