<?php
require('database.php');

$statutt = "refusé";

$verification = $My_data_base->prepare("SELECT * FROM graduat WHERE statutt = ?");
$verification->execute(array($statutt));

?>