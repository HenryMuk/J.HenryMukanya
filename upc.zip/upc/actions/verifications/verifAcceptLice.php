<?php
require('database.php');

$statutt = "approuvé";

$verification = $My_data_base->prepare("SELECT * FROM license WHERE statutt = ? ORDER BY id DESC");
$verification->execute(array($statutt));

?>