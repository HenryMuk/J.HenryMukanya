<?php
session_start();
require('database.php');

if(isset($_POST["validate"]))
{

    $username = ($_POST["username"]);
    $code = ($_POST["code"]);
    
    $Verif = $My_data_base->prepare("SELECT * FROM admin WHERE username = ?");
    $Verif->execute(array($username));

    if($Verif->rowCount() > 0)
    {
        $admin = $Verif->fetch();
      
        if($code == $admin["code"])
        {
            header('Location: index.php');
        }
        else
        {
            $error = "Le code d'authentification est incorrect";
        }   
    }
    else
    {
        $error = "Votre nom d'utilisateur est incorrect";
    }
   
    

   
}

?>