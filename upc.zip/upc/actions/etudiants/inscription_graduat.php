<?php
require('database.php');


if(isset($_POST["validate"]))
{

    $nom = $_POST["nom"];
    $postnom = $_POST["postnom"];
    $prenom = $_POST["prenom"];
    
    $telephone = $_POST["telephone"];
    $genre = $_POST["genre"];

    $email = $_POST["email"];
    $commune = $_POST["commune"];
    $quartier = $_POST["quartier"];
    $avenue = $_POST["avenue"];
    $numero = $_POST["numero"];


    $nationalite = $_POST["nationalite"];
    $date_naissance = $_POST["date_naissance"];
    $lieu_naissance = $_POST["lieu_naissance"];
    
    $promotion = $_POST["promotion"];
    $faculte = $_POST["faculte"];

    $nom_responsable = $_POST["nom_responsable"];
    $postnom_responsable = $_POST["postnom_responsable"];
    $prenom_responsable = $_POST["prenom_responsable"];
    $telephone_responsable = $_POST["telephone_responsable"];

    $code = generateCodeSuivi();
    $statutt = "En attente d'approbation";

    $fileNamediplome5 = $_FILES['diplome5']['name'];
    $fileNamediplome6 = $_FILES['diplome6']['name'];
    $fileNamebac = $_FILES['bac']['name'];
    $fileNamemotivation = $_FILES['motivation']['name'];
    $fileNamerelever = $_FILES['relever']['name'];
    
    
    if($promotion == "G1")
    {
        if($fileNamediplome5 != NULL && $fileNamediplome6 != NULL && $fileNamebac != NULL && $fileNamemotivation != NULL ){

            if($fileNamerelever != NULL)
            {
                $error = "Le relevé des côtes n'est pas demandé ! Veuillez fournir que les documents demandés.";
            }
            else
            {
                $fileSizediplome5 = $_FILES['diplome5']['size'];
            $tmpNamediplome5 = $_FILES['diplome5']['tmp_name'];
        
            $ValidExtensiondiplome5 = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $diplome5Extension = explode('.', $fileNamediplome5);
            $diplome5Extension = strtolower(end($diplome5Extension));
        
            if(!in_array($diplome5Extension, $ValidExtensiondiplome5))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizediplome5 > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newdiplome5Name = uniqid();
                $newdiplome5Name .= '.' . $diplome5Extension;
        
                move_uploaded_file($tmpNamediplome5, 'fichiers/'. $newdiplome5Name);
            }





            $fileSizediplome6 = $_FILES['diplome6']['size'];
            $tmpNamediplome6 = $_FILES['diplome6']['tmp_name'];
        
            $ValidExtensiondiplome6 = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $diplome6Extension = explode('.', $fileNamediplome6);
            $diplome6Extension = strtolower(end($diplome6Extension));
        
            if(!in_array($diplome6Extension, $ValidExtensiondiplome6))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizediplome6 > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newdiplome6Name = uniqid();
                $newdiplome6Name .= '.' . $diplome6Extension;
        
                move_uploaded_file($tmpNamediplome6, 'fichiers/'. $newdiplome6Name);
            }
        
        
            
            $fileSizebac = $_FILES['bac']['size'];
            $tmpNamebac = $_FILES['bac']['tmp_name'];
        
            $ValidExtensionbac = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $bacExtension = explode('.', $fileNamebac);
            $bacExtension = strtolower(end($bacExtension));
        
            if(!in_array($bacExtension, $ValidExtensionbac))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizebac > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newbacName = uniqid();
                $newbacName .= '.' . $bacExtension;
        
                move_uploaded_file($tmpNamebac, 'fichiers/'. $newbacName);
            }
        
        
            
            $fileSizemotivation = $_FILES['motivation']['size'];
            $tmpNamemotivation = $_FILES['motivation']['tmp_name'];
        
            $ValidExtensionmotivation = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $motivationExtension = explode('.', $fileNamemotivation);
            $motivationExtension = strtolower(end($motivationExtension));
        
            if(!in_array($motivationExtension, $ValidExtensionmotivation))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizemotivation > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newmotivationName = uniqid();
                $newmotivationName .= '.' . $motivationExtension;
        
                move_uploaded_file($tmpNamemotivation, 'fichiers/'. $newmotivationName);
            }
        
            
            
        
            $Inscription = $My_data_base->prepare("INSERT INTO graduat(nom, postnom, prenom, telephone, genre,email,commune,quartier,avenue,numero, nationalite, date_naissance, lieu_naissance, diplome5,diplome6, bac, motivation, promotion, faculte,nom_responsable,postnom_responsable,prenom_responsable,telephone_responsable, code,statutt) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $Inscription->execute(array($nom, $postnom, $prenom,$telephone, $genre,$email,$commune,$quartier,$avenue,$numero, $nationalite,$date_naissance,$lieu_naissance,$newdiplome5Name,$newdiplome6Name,$newbacName,$newmotivationName,$promotion,$faculte,$nom_responsable,$postnom_responsable,$prenom_responsable,$telephone_responsable,$code,$statutt));
            
            $success = "Inscription réçue ! Votre code est : $code Ce code vous servira à vérifier l'évolution de votre inscription dans l'espace [vérification]";

            }
    
            
        
            }
            else{

                $error = "Veuillez fournir les documents demandés !";
        
        
            }





    }
    else
    {
        if($fileNamediplome5 != NULL && $fileNamediplome6 != NULL && $fileNamebac != NULL && $fileNamemotivation != NULL && $fileNamerelever != NULL){

    
            $fileSizediplome5 = $_FILES['diplome5']['size'];
            $tmpNamediplome5 = $_FILES['diplome5']['tmp_name'];
        
            $ValidExtensiondiplome5 = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $diplome5Extension = explode('.', $fileNamediplome5);
            $diplome5Extension = strtolower(end($diplome5Extension));
        
            if(!in_array($diplome5Extension, $ValidExtensiondiplome5))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizediplome5 > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newdiplome5Name = uniqid();
                $newdiplome5Name .= '.' . $diplome5Extension;
        
                move_uploaded_file($tmpNamediplome5, 'fichiers/'. $newdiplome5Name);
            }





            $fileSizediplome6 = $_FILES['diplome6']['size'];
            $tmpNamediplome6 = $_FILES['diplome6']['tmp_name'];
        
            $ValidExtensiondiplome6 = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $diplome6Extension = explode('.', $fileNamediplome6);
            $diplome6Extension = strtolower(end($diplome6Extension));
        
            if(!in_array($diplome6Extension, $ValidExtensiondiplome6))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizediplome6 > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newdiplome6Name = uniqid();
                $newdiplome6Name .= '.' . $diplome6Extension;
        
                move_uploaded_file($tmpNamediplome6, 'fichiers/'. $newdiplome6Name);
            }
        
        
            
            $fileSizebac = $_FILES['bac']['size'];
            $tmpNamebac = $_FILES['bac']['tmp_name'];
        
            $ValidExtensionbac = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $bacExtension = explode('.', $fileNamebac);
            $bacExtension = strtolower(end($bacExtension));
        
            if(!in_array($bacExtension, $ValidExtensionbac))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizebac > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newbacName = uniqid();
                $newbacName .= '.' . $bacExtension;
        
                move_uploaded_file($tmpNamebac, 'fichiers/'. $newbacName);
            }
        
        
            
            $fileSizemotivation = $_FILES['motivation']['size'];
            $tmpNamemotivation = $_FILES['motivation']['tmp_name'];
        
            $ValidExtensionmotivation = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $motivationExtension = explode('.', $fileNamemotivation);
            $motivationExtension = strtolower(end($motivationExtension));
        
            if(!in_array($motivationExtension, $ValidExtensionmotivation))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizemotivation > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newmotivationName = uniqid();
                $newmotivationName .= '.' . $motivationExtension;
        
                move_uploaded_file($tmpNamemotivation, 'fichiers/'. $newmotivationName);
            }



            $fileSizerelever = $_FILES['relever']['size'];
            $tmpNamerelever = $_FILES['relever']['tmp_name'];
        
            $ValidExtensionrelever = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $releverExtension = explode('.', $fileNamerelever);
            $releverExtension = strtolower(end($releverExtension));
        
            if(!in_array($releverExtension, $ValidExtensionrelever))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizerelever > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newreleverName = uniqid();
                $newreleverName .= '.' . $releverExtension;
        
                move_uploaded_file($tmpNamerelever, 'fichiers/'. $newreleverName);
            }
        
            
            
        
            $Inscription = $My_data_base->prepare("INSERT INTO graduat(nom, postnom, prenom, telephone, genre,email,commune,quartier,avenue,numero, nationalite, date_naissance, lieu_naissance, diplome5,diplome6, bac, motivation,relever, promotion, faculte,nom_responsable,postnom_responsable,prenom_responsable,telephone_responsable, code,statutt) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $Inscription->execute(array($nom, $postnom, $prenom,$telephone, $genre,$email,$commune,$quartier,$avenue,$numero, $nationalite,$date_naissance,$lieu_naissance,$newdiplome5Name,$newdiplome6Name,$newbacName,$newmotivationName,$newreleverName,$promotion,$faculte,$nom_responsable,$postnom_responsable,$prenom_responsable,$telephone_responsable,$code,$statutt));
            
            $success = "Inscription réçue ! Votre code est : $code Ce code vous servira à vérifier l'évolution de votre inscription dans l'espace [vérification]";
        
            }
            else{

                $error = "Veuillez fournir les documents demandés !";
        
        
            }
    }

   

         

   

    
}
function generateCodeSuivi() {
    return 'CS' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}


?>