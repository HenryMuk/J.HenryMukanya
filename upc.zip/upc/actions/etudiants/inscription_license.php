<?php
require('database.php');


if(isset($_POST["validate"]))
{

    $nom = $_POST["nom"];
    $postnom = $_POST["postnom"];
    $prenom = $_POST["prenom"];
    $telephone = $_POST["telephone"];
    $genre = $_POST["genre"];

    $email = $_POST["email"];
    $commune = $_POST["commune"];
    $quartier = $_POST["quartier"];
    $avenue = $_POST["avenue"];
    $numero = $_POST["numero"];

    $nationalite = $_POST["nationalite"];
    $date_naissance = $_POST["date_naissance"];
    $lieu_naissance = $_POST["lieu_naissance"];
    
    $promotion = $_POST["promotion"];
    $faculte = $_POST["faculte"];

    $nom_responsable = $_POST["nom_responsable"];
    $postnom_responsable = $_POST["postnom_responsable"];
    $prenom_responsable = $_POST["prenom_responsable"];
    $telephone_responsable = $_POST["telephone_responsable"];

    $code = generateCodeSuivi();
    $statutt = "En attente d'approbation";

    $fileNamerelever = $_FILES['relever']['name'];
    $fileNamebac = $_FILES['bac']['name'];
    $fileNamemotivation = $_FILES['motivation']['name'];
    $fileNamediplomeGraduat = $_FILES['diplomeGraduat']['name'];

   

         if($fileNamerelever != NULL && $fileNamebac != NULL && $fileNamemotivation != NULL){

    
            $fileSizerelever = $_FILES['relever']['size'];
            $tmpNamerelever = $_FILES['relever']['tmp_name'];
        
            $ValidExtensionrelever = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $releverExtension = explode('.', $fileNamerelever);
            $releverExtension = strtolower(end($releverExtension));
        
            if(!in_array($releverExtension, $ValidExtensionrelever))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizerelever > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newreleverName = uniqid();
                $newreleverName .= '.' . $releverExtension;
        
                move_uploaded_file($tmpNamerelever, 'fichiers/'. $newreleverName);
            }

            $fileSizebac = $_FILES['bac']['size'];
            $tmpNamebac = $_FILES['bac']['tmp_name'];
        
            $ValidExtensionbac = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $bacExtension = explode('.', $fileNamebac);
            $bacExtension = strtolower(end($bacExtension));
        
            if(!in_array($bacExtension, $ValidExtensionbac))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizebac > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newbacName = uniqid();
                $newbacName .= '.' . $bacExtension;
        
                move_uploaded_file($tmpNamebac, 'fichiers/'. $newbacName);
            }

            $fileSizemotivation = $_FILES['motivation']['size'];
            $tmpNamemotivation = $_FILES['motivation']['tmp_name'];
        
            $ValidExtensionmotivation = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $motivationExtension = explode('.', $fileNamemotivation);
            $motivationExtension = strtolower(end($motivationExtension));
        
            if(!in_array($motivationExtension, $ValidExtensionmotivation))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizemotivation > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newmotivationName = uniqid();
                $newmotivationName .= '.' . $motivationExtension;
        
                move_uploaded_file($tmpNamemotivation, 'fichiers/'. $newmotivationName);
            }


            $fileSizediplomeGraduat = $_FILES['diplomeGraduat']['size'];
            $tmpNamediplomeGraduat = $_FILES['diplomeGraduat']['tmp_name'];
        
            $ValidExtensiondiplomeGraduat = ['png', 'jpg', 'jpeg','docx','xlsx'];
            $diplomeGraduatExtension = explode('.', $fileNamediplomeGraduat);
            $diplomeGraduatExtension = strtolower(end($diplomeGraduatExtension));
        
            if(!in_array($diplomeGraduatExtension, $ValidExtensiondiplomeGraduat))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSizediplomeGraduat > 10000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newdiplomeGraduatName = uniqid();
                $newdiplomeGraduatName .= '.' . $diplomeGraduatExtension;
        
                move_uploaded_file($tmpNamediplomeGraduat, 'fichiers/'. $newdiplomeGraduatName);
            }
        
        
        
           
        
            
            
        
            $Inscription = $My_data_base->prepare("INSERT INTO license(nom, postnom, prenom, telephone, genre,email,commune,quartier,avenue,numero, nationalite, date_naissance, lieu_naissance,bac, relever, motivation,diplomeGraduat,promotion, faculte,nom_responsable,postnom_responsable,prenom_responsable,telephone_responsable, code,statutt) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $Inscription->execute(array($nom, $postnom, $prenom,$telephone, $genre,$email,$commune,$quartier,$avenue,$numero, $nationalite,$date_naissance,$lieu_naissance,$newbacName,$newreleverName,$newmotivationName,$newdiplomeGraduatName,$promotion,$faculte,$nom_responsable,$postnom_responsable,$prenom_responsable,$telephone_responsable,$code,$statutt));
            
            $success = "Inscription réçue ! Votre code est : $code Ce code vous servira à vérifier l'évolution de votre inscription dans l'espace [vérification]";
        
            }
            else{

                $error = "Veuillez fournir les documents demandés !";
        
        
            }

   

    
}
function generateCodeSuivi() {
    return 'CS' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}


?>