<?php
require('database.php');

if(isset($_POST['verifier']))
{
    
    $code = $_POST['code'];
    

    $CheckEtudiant1 = $My_data_base->prepare("SELECT * FROM graduat WHERE code = ?");
    $CheckEtudiant1->execute(array($code));

    if($CheckEtudiant1->rowCount() > 0){

        $Etudiant = $CheckEtudiant1->fetch();

        $le_statutt = $Etudiant['statutt'];

        if($le_statutt == "approuvé"){

            $approuve = "Félicitation vous avez été reçu !";
        }
        else if($le_statutt == "refusé"){
            $refuse = "Désolé, votre inscription n'a pas été approuvée";
        }
        else{
            $attente = "Veuillez patienter, votre inscription est en cours de traitement...";
        }

    }


    /*=================================================================================================== */



    $CheckEtudiant2 = $My_data_base->prepare("SELECT * FROM license WHERE code = ?");
    $CheckEtudiant2->execute(array($code));

    if($CheckEtudiant2->rowCount() > 0){

        $Etudiant = $CheckEtudiant2->fetch();

        $le_statutt = $Etudiant['statutt'];

        if($le_statutt == "approuvé"){

            $approuve = "Félicitation vous avez été reçu !";
        }
        else if($le_statutt == "refusé"){
            $refuse = "Désolé, votre inscription n'a pas été approuvée";
        }
        else{
            $attente = "Veuillez patienter, votre inscription est en cours de traitement...";
        }

    }
    else{
        $message = "Code non attribué, veuillez correctement saisir le code";
    }



    
}

?>