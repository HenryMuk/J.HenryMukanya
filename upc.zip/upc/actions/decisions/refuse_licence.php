<?php
require('database.php');


if(isset($_GET['id']) && !empty($_GET['id']))
{
    
    $idEtudiant = $_GET['id'];
    $new_statutt = "refusé";

    $RefuseEtudiant = $My_data_base->prepare("UPDATE license SET statutt = ? WHERE id = ?");
    $RefuseEtudiant->execute(array($new_statutt, $idEtudiant));

    header('Location: ../../admin/index.php');
}

?>