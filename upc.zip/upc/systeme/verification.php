<?php
require('../actions/code/verifcode.php');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification du Statut</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: white;
        }

        #sidebar {
            height: 100%;
            width: 50px;
            position: fixed;
            background-color: #343a40;;
            padding-top: 20px;
            overflow-x: hidden;
        }

        #sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: #dee2e6;
            display: block;
            transition: 0.3s;
        }

        #sidebar a:hover {
            background-color: #495057;
            color: white;
        }

        #sidebar i {
            margin-right: 10px;
        }

        #content {
            margin-left: 50px;
            padding: 16px;
        }

        .page-title {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .card {
            background-color: white;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.1);
        }

        .card-body {
            padding: 20px;
            text-align: center;
        }

        .card-title {
            font-size: 18px;
            margin-top: 15px;
            color: #495057;
        }

        main {
            padding: 20px;
        }

        .message {
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 15px;
            padding: 15px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .message p {
            margin: 0;
        }

        .message small {
            color: #666;
        }

        @media (max-width: 600px) {
            header h1 {
                font-size: 1.2em;
            }

            main {
                padding: 10px;
            }

            .message {
                padding: 10px;
            }
        }

    </style>
</head>



<body>

    <div id="sidebar">
        <a href="./index.php" style="background-color: #495057;"><i class="fas fa-arrow-left"></i></a>
    </div>

    <div id="content">
        <h1 class="page-title">Vérification de l'inscription</h1>
        
        
        
            <form action="" method="post" id="contactForm">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-key"></i></span>
                    <input type="text" aria-label="code_suivi" class="form-control" placeholder="Code de Vérification" name="code" required>
                </div><hr>
                <button type="submit" class="btn btn-outline-success" name="verifier"><i class="fas fa-user-plus"></i> Vérifier</button><br><br>
            <?php if (isset($approuve)) : ?>
                <div style="width:100%;" class="alert alert-success alert-dismissible fade show m-auto" role="alert">
                    <?php echo $approuve; ?>
                </div>

            <?php elseif (isset($refuse)) : ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $refuse; ?>
                </div>
            <?php elseif (isset($attente)) : ?>
            <div class="alert alert" role="alert">
                    <?php echo $attente; ?>
                </div>
                <?php elseif (isset($message)) : ?>
            <div class="alert alert" role="alert">
                    <?php echo $message; ?>
                </div>
                <?php endif ; ?>
            </form>

</body>

</html>

