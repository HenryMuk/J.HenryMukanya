<?php
require('../actions/etudiants/inscription_license.php');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>License</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="../Images/logo_1.png" rel="icon">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: white;
        }

        #sidebar {
            height: 100%;
            width: 50px;
            position: fixed;
            background-color: #343a40;;
            padding-top: 20px;
            overflow-x: hidden;
        }

        #sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: #dee2e6;
            display: block;
            transition: 0.3s;
        }

        #sidebar a:hover {
            background-color: #495057;
            color: white;
        }

        #sidebar i {
            margin-right: 10px;
        }

        #content {
            margin-left: 50px;
            padding: 16px;
        }

        .page-title {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .card {
            background-color: white;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.1);
        }

        .card-body {
            padding: 20px;
            text-align: center;
        }

        .card-title {
            font-size: 18px;
            margin-top: 15px;
            color: #495057;
        }

        main {
            padding: 20px;
        }

        .message {
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 15px;
            padding: 15px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .message p {
            margin: 0;
        }

        .message small {
            color: #666;
        }

        @media (max-width: 600px) {
            header h1 {
                font-size: 1.2em;
            }

            main {
                padding: 10px;
            }

            .message {
                padding: 10px;
            }
        }

    </style>
</head>



<body>

    <div id="sidebar">
        <a href="./index.php" style="background-color: #495057;"><i class="fas fa-arrow-left"></i></a>
    </div>

    <div id="content">
        <h1 class="page-title">Inscription en License</h1>

        <form id="multi-step-form" method="post" enctype="multipart/form-data">
            <hr>
            <?php if (isset($success)) : ?>
                <div style="width:100%;" class="alert alert-success alert-dismissible fade show m-auto" role="alert">
                    <?php echo $success; ?>
                </div>
            <?php elseif (isset($error)) : ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error; ?>
                    </div>
            <?php endif; ?>

            
            <hr>
            <div id="step1" class="step">
            <h1 class="page-title">1. Informations sur l'étudiant</h1>
                <div class="mb-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="nom" class="form-control" placeholder="Nom" required>
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="postnom" class="form-control" placeholder="Post-nom" required>
                        </div>
                        <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="prenom" class="form-control" placeholder="Prénom" required>
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="telephone" class="form-control" placeholder="Téléphone" required>
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="email" class="form-control" placeholder="Adresse-email" required>
                    
                    </div><hr>
                    
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-venus-mars"></i></span>
                        <select name="genre" class="form-control" required>
                            <option value="">Genre</option>
                            <option value=""></option>
                            <option value="Masculin">Masculin</option>
                            <option value="Féminin">Féminin</option>
                        </select>
                        <span class="input-group-text"><i class="fas fa-flag"></i></span>
                        <input type="text" aria-label="First name" name="nationalite" class="form-control" placeholder="Nationalité" required>
                    </div><hr>
                
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                        <input type="date" aria-label="First name" class="form-control" name="date_naissance" required>
                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        <input type="text" aria-label="First name" class="form-control" placeholder="Lieu de naissance" name="lieu_naissance" required>
                    </div><hr>

                    <h1 class="page-title">2. Adresse</h1>
                    
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        <select name="commune" class="form-control" required>
                            <option value="">Commune</option>
                            <option value="bumbu">Bumbu</option>
                            <option value="gombe">Gombe</option>
                            <option value="kalamu">Kalamu</option>
                            <option value="kasavubu">Kasavubu</option>
                            <option value="kimbanseke">Kimbanseke</option>
                            <option value="kintambo">Kintambo</option>
                            <option value="kisenso">Kisenso</option>
                            <option value="kasa-vubu">Kasa-Vubu</option>
                            <option value="limete">Limete</option>
                            <option value="lingwala">Lingwala</option>
                            <option value="makala">Makala</option>
                            <option value="maluku">Maluku</option>
                            <option value="masina">Masina</option>
                            <option value="matete">Matete</option>
                            <option value="mont-ngafula">Mont Ngafula</option>
                            <option value="ngaba">Ngaba</option>
                            <option value="ngaliema">Ngaliema</option>
                        </select>
                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        <input type="text" aria-label="First name" class="form-control" placeholder="Quartier" name="quartier" required>
                    </div><hr>  
                    
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        <input type="text" aria-label="First name" class="form-control" placeholder="Avenue" name="avenue" required>
                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        <input type="text" aria-label="First name" class="form-control" placeholder="Numéro" name="numero" required>
                    </div><hr>

                    <h1 class="page-title">3. Inscription souhaitée</h1>

                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-school"></i></span>
                        <select name="promotion" class="form-control" required>
                            <option value="L1">L1</option>
                            <option value="L2">L2</option>
                        </select>
                        <span class="input-group-text"><i class="fas fa-school"></i></span>
                        <select name="faculte" class="form-control" required>
                            <option value="Faculté de Droit">Faculté de Droit</option>
                            <option value="Faculté d'Economie">Faculté d'Economie</option>
                            <option value="Faculté d'Informatique">Faculté d'Informatique</option>
                            <option value="Faculté de Medecine">Faculté de Medecine</option>
                            <option value="Faculté de Théologie">Faculté de Théologie</option>
                        </select>
                    </div><hr>

                    <h1 class="page-title">4. Documents à fournir</h1>

                    
                        <span class="input-group-text" style="font-weight:bold;">Ci-dessous sélectionner le relevé de côtes*</span>
                        <input type="file" aria-label="First name" name="relever" id="relever" class="form-control" >
                        
                        <span class="input-group-text" style="font-weight:bold;">Ci-dessous sélectionner l'attestation de reussite d'études humanitaires(Baccalauréat)*</span>
                        <input type="file" aria-label="First name" name="bac" id="bac" class="form-control" >
                        
                        <span class="input-group-text" style="font-weight:bold;">Ci-dessous sélectionner la lettre de motivation*</span>
                        <input type="file" aria-label="First name" name="motivation" id="motivation" class="form-control" >
                        
                        <span class="input-group-text" style="font-weight:bold;">Ci-dessous sélectionner le diplôme de graduat*</span>
                        <input type="file" aria-label="First name" name="diplomeGraduat" id="diplomeGraduat" class="form-control" >
                    
                       
                   
                        <hr>

                    <?php if(isset($error)): ?>
                    <div style="width:100%;" class="alert alert-danger alert-dismissible fade show m-auto" role="alert">
                    <?php echo $error; ?>
                    </div>
                    <?php endif; ?>

                    <h1 class="page-title">5. Informations sur la personne de confiance</h1>
                <div class="mb-3">
                    <div class="input-group">
                    <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="nom_responsable" class="form-control" placeholder="Nom" required>
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="postnom_responsable" class="form-control" placeholder="Post-nom" required>
                        </div>
                        <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="prenom_responsable" class="form-control" placeholder="Prénom" required>
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" aria-label="First name" name="telephone_responsable" class="form-control" placeholder="Téléphone" required>
                    </div><hr>
                    </div><hr>

                    <button type="submit" name="validate" class="btn btn-outline-success"><i class="fas fa-user-plus"></i> S'Inscrire</button><br><br>
                    

                </div>
            </div>

            

            
        </form>
           
    </div>

    
</body>
</html>
