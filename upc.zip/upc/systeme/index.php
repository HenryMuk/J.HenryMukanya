<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ntumba University</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.1.2/dist/tailwind.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <!-- Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <!-- Custom CSS -->
    <style>
        .navbar {
            background-color: #1a202c; /* Dark color */
        }
        .navbar-brand {
            font-size: 1.5rem;
            color: #fff;
        }
        .section {
            padding: 3rem 0;
            transition: all 0.3s ease-in-out;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .section:hover {
            transform: scale(1.05);
        }
        .bg-primary {
            background-color: #3182ce; /* Tailwind blue */
        }
        .bg-secondary {
            background-color: #2d3748; /* Tailwind gray */
        }
        .bg-accent {
            background-color: #4a5568; /* Tailwind darker gray */
        }
        .section-title {
            color: #fff;
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
        }
        .section p {
            font-size: 1.2rem;
        }
        .btn {
            font-size: 1.1rem;
        }
        .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #fff;
        }
    </style>
</head>







<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            
            <a class="navbar-brand" href="#">Ntumba University</a> 
    
        </div>
        
    </nav>

    <!-- Sections -->
    <div class="container mt-5">
        <div class="section bg-primary text-white text-center rounded animate__animated animate__fadeInUp">
            <i class="fas fa-user-graduate icon"></i>
            <h2 class="section-title">Inscription en Graduat</h2>
            <p>Procédez à votre inscription en Graduat ici.</p><br>
            <a href="graduat.php" class="btn btn-light btn-lg"><i class="fas fa-plus-circle"></i> S'inscrire</a>
        </div>

        <div class="section bg-secondary text-white text-center rounded mt-5 animate__animated animate__fadeInUp" style="animation-delay: 0.2s;">
            <i class="fas fa-user-tie icon"></i>
            <h2 class="section-title">Inscription en Licence</h2>
            <p>Procédez à votre inscription en Licence ici.</p><br>
            <a href="licence.php" class="btn btn-light btn-lg"><i class="fas fa-plus-circle"></i> S'inscrire</a>
        </div>

        <div class="section bg-accent text-white text-center rounded mt-5 animate__animated animate__fadeInUp" style="animation-delay: 0.4s;">
            <i class="fas fa-check-circle icon"></i>
            <h2 class="section-title">Vérification de l'inscription</h2>
            <p>Vérifiez l'état de votre inscription ici.</p><br>
            <a href="verification.php" class="btn btn-light btn-lg"><i class="fas fa-user"></i> Vérifier</a>
        </div><br><br>
    </div>

    <a class="navbar-brand" href="../admin/connect.php" style="font-size:5px;">Ntumba University</a> 

</body>
</html>
