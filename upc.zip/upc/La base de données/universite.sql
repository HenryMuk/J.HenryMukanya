-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 03 août 2024 à 19:02
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `universite`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `username`, `code`) VALUES
(1, 'Emma', '1234');

-- --------------------------------------------------------

--
-- Structure de la table `graduat`
--

CREATE TABLE `graduat` (
  `id` int(255) NOT NULL,
  `nom` text NOT NULL,
  `postnom` text NOT NULL,
  `prenom` text NOT NULL,
  `telephone` text NOT NULL,
  `genre` text NOT NULL,
  `email` text NOT NULL,
  `commune` text NOT NULL,
  `quartier` text NOT NULL,
  `avenue` text NOT NULL,
  `numero` text NOT NULL,
  `nationalite` text NOT NULL,
  `date_naissance` date NOT NULL,
  `lieu_naissance` text NOT NULL,
  `diplome5` text NOT NULL,
  `diplome6` text NOT NULL,
  `bac` text NOT NULL,
  `motivation` text NOT NULL,
  `relever` text NOT NULL,
  `promotion` text NOT NULL,
  `faculte` text NOT NULL,
  `nom_responsable` text NOT NULL,
  `postnom_responsable` text NOT NULL,
  `prenom_responsable` text NOT NULL,
  `telephone_responsable` text NOT NULL,
  `code` text NOT NULL,
  `statutt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `license`
--

CREATE TABLE `license` (
  `id` int(255) NOT NULL,
  `nom` text NOT NULL,
  `postnom` text NOT NULL,
  `prenom` text NOT NULL,
  `telephone` text NOT NULL,
  `genre` text NOT NULL,
  `email` text NOT NULL,
  `commune` text NOT NULL,
  `quartier` text NOT NULL,
  `avenue` text NOT NULL,
  `numero` text NOT NULL,
  `nationalite` text NOT NULL,
  `date_naissance` date NOT NULL,
  `lieu_naissance` text NOT NULL,
  `bac` text NOT NULL,
  `relever` text NOT NULL,
  `motivation` text NOT NULL,
  `promotion` text NOT NULL,
  `diplomeGraduat` text NOT NULL,
  `faculte` text NOT NULL,
  `nom_responsable` text NOT NULL,
  `postnom_responsable` text NOT NULL,
  `prenom_responsable` text NOT NULL,
  `telephone_responsable` text NOT NULL,
  `code` text NOT NULL,
  `statutt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `graduat`
--
ALTER TABLE `graduat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `license`
--
ALTER TABLE `license`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `graduat`
--
ALTER TABLE `graduat`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `license`
--
ALTER TABLE `license`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
