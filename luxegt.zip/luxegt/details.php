<?php
require("action/achat.php");
?>

<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Bienvenue sur notre site</title>
  <link rel="stylesheet" href="assets/css/fontawesome.css">

  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <header class="entete">
    <div class="espaceur">
      <nav class="navigation ">
        <a href="index.html" class="logo">
          <img src="assets/images/logo.png" alt="" style="width: 158px;">
        </a>
        <ul class="liens">
        <li><a href="index.php" class="clique">Acceuil</a></li>
           
            <?php
              if(!(isset($_SESSION["auth"]))){
            ?>
            <li><a href="inscription.php">Inscription</a></li>
            <li><a class="important" href="connexion.php">Connexion</a></li>
              <?php 
              }else{
              ?>
              <li><a class="important" href="action/deconnet.php">Déconnexion</a></li>
              <?php
              }
              ?>
        </ul>
      </nav>

      <center>
        <br><br>
        <h3 class="titre-centre">Villa air craft à kivu Nord ® II</h3>
      </center>

    </div>
    <div class="diviseur"></div>
  </header>

  <br><br>

  <div class="espaceur">
    <div class="parties details">
      <div class="gauche">
        <img src="images/maison-6.jpg" alt="">
      </div>
      <div class="droite">
      </div>
      <h2>Paiement en ligne</h2>
      </div>
      <br>
      <br>
      <form action="" method="post">
      <div class="paiement-container">
        <label for="nom">Identité:</label>
        <input type="text" id="identite" name="identite" required>
  
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
  
        <div class="row">
          <div>
            <label for="numero-carte">Numéro de carte:</label>
            <input type="text" id="numero-carte" name="numero-carte" required>
          </div>
         
        </div>
  
        <div class="row">
          <div>
            <label for="code-securite">Code de sécurité:</label>
            <input type="text" id="code-securite" name="code-securite" required>
          </div>
        </div>
        <br>
        <button class="bouton" name="acheter" type="submit"><i class="fa fa-shopping-bag">Acheter maintenant !</i></button>
        <table>
        </table>
 
        </form>
         

    <div class="contenu-description">
      <h3 class="titre-rose"


  <footer>
    <div class="espaceur">
      <br><br>
      <center>
        <p>Bienvenue dans notre site internet de location des maisons </p>
      </center>
    </div>
  </footer>

</body>

</html>