<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';



require('database.php');

$mail = new PHPMailer(true);

if(isset($_POST["validate"]))
{

    $username = htmlspecialchars($_POST["username"]);
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $mdp = password_hash($_POST["mdp"], PASSWORD_DEFAULT);

    
    $VerifIfUserExist = $My_data_base->prepare("SELECT username FROM users WHERE username = ?");
    $VerifIfUserExist->execute(array($username));

    if($VerifIfUserExist->rowCount() == 0)
    {

            $InsertUser = $My_data_base->prepare('INSERT INTO users(username, name, email, mdp) VALUES(?,?,?,?)');
            $InsertUser->execute(array($username, $name, $email, $mdp));

            $RecupUser = $My_data_base->prepare('SELECT id , username, name , email  FROM users WHERE username = ? AND name = ? AND email = ?');
            $RecupUser->execute(array($username, $name, $email));

            $UserInfos = $RecupUser->fetch();

            $_SESSION['auth'] = true;
            $_SESSION['id'] = $UserInfos['id'];
            $_SESSION['username'] = $UserInfos['username'];
            $_SESSION['name'] =  $UserInfos['name'];
            $_SESSION['email'] =  $UserInfos['email'];
        
            try
            {
                        
                        $mail->IsSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true; 
    
                        $mail->SMTPOptions = array(
                            'ssl' => array(
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                            )
                            );
                
                        $mail->SMTPSecure = 'tls'; 
                        $mail->Port = '587';  
                        $mail->Username = 'SampleCodingManager@gmail.com';
                        $mail->Password = 'nrgoozhhpdfvghex';   
                        $mail->setFrom('SampleCodingManager@gmail.com');
                        $mail->AddAddress('enocklomama@gmail.com');
                
                //   $path = 'reseller.pdf';
                //   $mail->AddAttachment($path);
                
                        $mail->IsHTML(true);
                        
                      
                        $mail->Subject = "Validation du compte";
                        $mail->Body = 
                        "
                        Nouveau utilisateur : <br>
                        Nom : $username <br>
                        Prenom : $name <br>
                        Adresse-mail : $email <br>
                        

                        
                        ";
                        
                        $mail->send();
                       
                   
            
                        header('Location: index.php');
    
                    
            }catch(Exception $e){
                echo $e->getMessage();
            }
        
                

                

        
    }
    else
    {
        echo '<script>alert("Ce nom d\'utilisateur est déjà prit");</script>';
    }
   
    
}


?>