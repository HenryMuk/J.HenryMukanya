<?php
session_start();

require('database.php');

if(isset($_POST["acheter"]))
{

    $identite = ($_POST["identite"]);
    $email = ($_POST["email"]);
    

    
    $InserAcheteur = $My_data_base->prepare('INSERT INTO acheteur(identite, email) VALUES(?,?)');
    $InserAcheteur->execute(array($identite, $email));

    header('Location: index.php');

   
   
    
}


?>