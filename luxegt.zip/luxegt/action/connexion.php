<?php
session_start();
require('database.php');

if(isset($_POST["validate"]))
{

    $name = htmlspecialchars($_POST["name"]);
    $mdp = htmlspecialchars($_POST["mdp"]);
    
    $VerifIfUserExist = $My_data_base->prepare("SELECT * FROM users WHERE name = ?");
    $VerifIfUserExist->execute(array($name));

    if($VerifIfUserExist->rowCount() > 0)
    {
        $UserInfos = $VerifIfUserExist->fetch();
      
        if(password_verify($mdp, $UserInfos["mdp"]))
        {
            $_SESSION['auth'] = true;
            $_SESSION['id'] = $UserInfos['id'];
            $_SESSION['username'] = $UserInfos['username'];
            $_SESSION['name'] =  $UserInfos['name'];
            $_SESSION['email'] =  $UserInfos['email'];
            header('Location: index.php');
        }
        else
        {
            echo '<script>alert("Le mot de passe est incorrect");</script>';
        }   
    }
    else
    {
        echo '<script>alert("Votre nom d\'utilisateur est incorrect");</script>';
    }
   
    

   
}

?>