<?php require('action/connexion.php');?>


<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Bienvenue sur notre site</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header class="entete">
        <div class="espaceur">
            <nav class="navigation ">
                <a href="index.html" class="logo">
                    <img src="assets/images/logo.png" alt="" style="width: 158px;">
                </a>
                <ul class="liens">
                <li><a href="index.php" class="clique">Acceuil</a></li>
          <li><a href="contact.php">Contactez-nous</a></li>
       
          <li><a href="inscription.php">Inscription</a></li>
          <li><a class="important" href="connexion.php">Connexion</a></li>
                </ul>
            </nav>

            <center>
                <br><br>
                <h3 class="titre-centre">Contactez-nous</h3>
            </center>

        </div>
        <div class="diviseur"></div>
    </header>

    <br><br>

    <div class="contact espaceur">
        <div class="parties">
            <div class="gauche">
                <h6 class="titre-rose">Contactez-nous</h6>
                <h2 class="titre-grand">Connectez-vous maintenant !</h2>
                <p class="description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum maiores maxime
                    ratione
                    sapiente quae nihil sequi quidem ullam reprehenderit, excepturi temporibus, quod ad, amet esse
                    provident
                    placeat repellendus cumque qui.</p>
            </div>
            <form method="POST" action="">

            <div class="droite">
                <h6 class="titre-rose">Formulaire</h6>
                <h2 class="titre-grand">Renseignez vos informations</h2>
                <br><br><br>
                <div class="parties">
                    <div class="gauche">
                        <input type="name" name="name" id="name" placeholder="Votre nom..." autocomplete="on" required>
                    </div>
                    <div class="droite">
                        <input type="password" name="mdp" id="mdp" placeholder="Votre mot de passe..."
                            autocomplete="on" required>
                    </div>
                </div> <button class="bouton" type="submit" name="validate">
                    Se conencter
                </button>

                </form>

            </div>
        </div>
    </div>

    <footer>
        <div class="espaceur">
            <br><br>
            <center>
                <p>Bienvenue dans notre site internet de location des maisons </p>
            </center>
        </div>
    </footer>

</body>

</html>