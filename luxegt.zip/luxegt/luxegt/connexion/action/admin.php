<?Php
require('database.php');

$RecupAcheteur = $My_data_base->query("SELECT * FROM users");

?>