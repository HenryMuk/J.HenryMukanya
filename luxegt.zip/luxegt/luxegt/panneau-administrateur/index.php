<?php
require('action/admin.php');
?>

<!DOCTYPE html>
<html>
<head>
  <title>Panneau d'administration</title>
  <style>
    /* Styles CSS pour l'interface d'administration */
    body {
      font-family: 'Roboto', Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f5f5f5;
    }

    header {
      background-color: #4CAF50;
      color: #fff;
      padding: 20px;
      text-align: center;
    }

    nav {
      background-color: #fff;
      padding: 10px;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    nav a {
      color: #333;
      text-decoration: none;
      padding: 10px 20px;
      margin: 5px;
      transition: background-color 0.3s, color 0.3s;
    }

    nav a:hover {
      background-color: #4CAF50;
      color: #fff;
    }

    main {
      padding: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background-color: #fff;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    th, td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #4CAF50;
      color: #fff;
    }

    footer {
      background-color: #4CAF50;
      color: #fff;
      padding: 10px;
      text-align: center;
      box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
    }
  </style>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
  <header>
    <h1>Panneau d'administration</h1>
  </header>

  <nav>
    <a href="#">Tableau de bord</a>
    <a href="#">Utilisateurs</a>
    <a href="#">Contenus</a>
    <a href="#">Paramètres</a>
  </nav>

  <main>
    <h2>Gestion des achats</h2>
    <table>
      <thead>
        <tr>
          <th>Adresse e-mail</th>
          <th>Prix</th>
          <th>Nom complet</th>
          <th>Acheteur</th>
        </tr>
      </thead>
      <tbody>
        <?php while($acheteur = $RecupAcheteur->fetch()){ ?>
        <tr>
          <td><?=$acheteur['email'];?></td>
          <td>19,99 €</td>
          <td><?=$acheteur['username'];?></td>
          <td><?=$acheteur['name'];?></td>
        </tr>
        <?php } ?>
        
        <!-- Ajoutez d'autres lignes de données ici -->
      </tbody>
    </table>
  </main>

  <footer>
    <p>&copy; 2024 Panneau d'administration. Tous droits réservés.</p>
  </footer>
</body>
</html>