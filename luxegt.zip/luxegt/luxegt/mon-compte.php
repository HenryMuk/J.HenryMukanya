<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Bienvenue sur notre site</title>  

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header class="entete">
        <div class="espaceur">
            <nav class="navigation ">
                <a href="index.html" class="logo">
                    <img src="assets/images/logo.png" alt="" style="width: 158px;">
                </a>
                <ul class="liens">
                <li><a href="index.php" class="clique">Acceuil</a></li>
          <li><a href="contact.php">Contactez-nous</a></li>
       
          <li><a href="inscription.php">Inscription</a></li>
          <li><a class="important" href="connexion.php">Connexion</a></li>
                </ul>
            </nav>

            <center>
                <br><br>
                <h3 class="titre-centre">Mon compte</h3>
            </center>

        </div>
        <div class="diviseur"></div>
    </header>

    <br><br>


    <div class="mis-en-ligne">
        <center>
            <div class="textes">
                <h6 class="petit-tire titre-rose">Mis en ligne</h6>
                <h2 class="titre-grand">Mes maisons publiées</h2>
            </div>
        </center>


        <div class="maisons-enligne parties espaceur">
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
            <div class="maison">
                <div class="image">
                    <a href="details.html"><img src="assets/images/maison-2.jpg" alt=""></a>
                    <span class="prix"><span class="barre">$28</span>$20</span>
                </div>
                <div class="informations">
                    <span class="categorie">Action</span>
                    <h4 class="lieu">Nom de la maison</h4>
                    <a href="details.html">Gérer</a>
                </div>
            </div>
        </div>
    </div>

    <div class="formulaire parties espaceur">
        <div class="droite">
            <h6>Indications</h6>
            <h2 class="titre-grand">Comment publier <br> une maison ?</h2>
            <br>
            <p class="description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui repellat maxime
                excepturi
                facilis magnam nihil.</p>

            <ul>
                <li><span>Etape 1</span>Lorem ipsum dolor sit amet consectetur, adipisicing elit </li>
                <li><span>Etape 2</span> Lorem ipsum dolor sit amet consectetur adipisicing elit. </li>
                <li><span>Etape 3</span> Lorem ipsum dolor sit amet consectetur adipisicing elit !</li>
            </ul>
        </div>
        <div class="gauche">
            <h6>Formulaire</h6>
            <h2 class="titre-grand">Remplissez <br> le formulaire !</h2>

            <form action="">
                <input type="text" name="name" id="name" placeholder="Titre à afficher" autocomplete="on" required>
                <input type="text" name="addresse" id="addresse" placeholder="Addresse complète" autocomplete="on"
                    required>
                <input type="phone" name="phone" id="phone" placeholder="Numéro de téléphone" autocomplete="on"
                    required>
                <input type="file" name="photo" id="photo" placeholder="Photo de la maison.." autocomplete="on"
                    required>
                <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your E-mail..."
                    required="">
                <input type="number" name="prix" id="prix" placeholder="Prix..." autocomplete="on">
                <textarea name="message" id="message"
                    placeholder="Description  (Informations supplémentaires)"></textarea>
                <button type="submit" class="bouton">Enregistrer</button>
            </form>
        </div>
    </div>

    <footer>
        <div class="espaceur">
            <br><br>
            <center>
                <p>Bienvenue dans notre site internet de location des maisons </p>
            </center>
        </div>
    </footer>
</body>

</html>