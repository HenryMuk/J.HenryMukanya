<?php
session_start();
require('action/contact.php');
?>

<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Bienvenue sur notre site</title>
 
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <header class="entete">
    <div class="espaceur">
      <nav class="navigation ">
        <a href="index.html" class="logo">
          <img src="assets/images/logo.png" alt="" style="width: 158px;">
        </a>
        <ul class="liens">
        <li><a href="index.php" class="clique">Acceuil</a></li>
           
            <?php
              if(!(isset($_SESSION["auth"]))){
            ?>
            <li><a href="inscription.php">Inscription</a></li>
            <li><a class="important" href="connexion.php">Connexion</a></li>
              <?php 
              }else{
              ?>
              <li><a class="important" href="action/deconnet.php">Déconnexion</a></li>
              <?php
              }
              ?>
        </ul>
      </nav>

      <center>
        <br><br>
        <h3 class="titre-centre">Contactez-nous</h3>
      </center>

    </div>
    <div class="diviseur"></div>
  </header>

  <br><br>

  <div class="contact espaceur">
    <div class="parties">
      <div class="gauche">
        <h6 class="titre-rose">Contactez-nous</h6>
        <h2 class="titre-grand">Bienvenue chez nous!</h2>
        <p class="description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum maiores maxime ratione
          sapiente quae nihil sequi quidem ullam reprehenderit, excepturi temporibus, quod ad, amet esse provident
          placeat repellendus cumque qui.</p>
      </div>
      <form method="POST" action="">



      
      <div class="droite">
        <div class="parties">
          <div class="gauche">
            <input  type="name" name="name" id="name" placeholder="Votre prenom..." autocomplete="on" required>

          </div>
          <div class="droite">
            <input type="surname" name="username" id="username" placeholder="Votre nom..." autocomplete="on" required>
          </div>
        </div>
        <div class="parties">
          <div class="gauche">
            <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Votre email..." required="">
          </div>

          
          
        </div>

        <textarea name="message" id="message" placeholder="Votre message"></textarea>
        <button class="bouton" type="submit" id="form-submit" name="validate" id="validate" class="orange-button">Envoyer le
          message</button>

          </form>

      </div>
    </div>
  </div>

  <footer>
    <div class="espaceur">
      <br><br>
      <center>
        <p>Bienvenue dans notre site internet de location des maisons </p>
      </center>
    </div>
  </footer>

</body>

</html>