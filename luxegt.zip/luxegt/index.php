<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Bienvenue sur notre site</title>
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <header class="entete">
    <div class="espaceur">
      <nav class="navigation ">
        <a href="index.html" class="logo">
          <img src="assets/images/logo.png" alt="" style="width: 158px;">
        </a>
        <ul class="liens">
          

            <li><a href="index.php" class="clique">Acceuil</a></li>
            
            <?php
              if(!(isset($_SESSION["auth"]))){
            ?>
            
            <li><a href="inscription.php">Inscription</a></li>
            <li><a class="important" href="connexion.php">Connexion</a></li>
              <?php 
              }else{
              ?>
              <li><a href="contact.php">Contactez-nous</a></li>
              <li><a class="important" href="action/deconnet.php">Déconnexion</a></li>
              <?php
              }
              ?>
          
        </ul>
      </nav>

      <div class="parties presentation">
        <div class="gauche ">
          <h6 class="petit-titre"> Bienvenue chez NearHouse</h6>
          <h2 class="titre">MAISONS PRETES À L'EMPLOI!</h2>
          <p class="description-texte">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Harum voluptatem
            perferendis enim reiciendis
            aliquid distinctio quo aut totam, voluptatibus officiis dolore tenetur ducimus ab libero exercitationem
            veniam eaque accusamus quibusdam.</p>
          
        </div>

        <div class="droite">
          <div class="image-flotant">
            <img width="200" src="assets/images/maison.jpg" alt="">
          </div>
        </div>
      </div>

    </div>
    <div class="diviseur"></div>
  </header>

  <center>
    <br><br>
    <h3 class="titre-rose">Disponibles</h3>
    <h1 class="titre-noir">Liste Des Maisons Disponibles</h1>
  </center>
  <div class="espaceur">
    <br><br>
    <div class="maisons">

      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
      <div class="maison">
        <div class="image">
          <a href="details.php"><img src="assets/images/maison-2.jpg" alt=""></a>
          <span class="prix"><span class="barre">$28</span>$20</span>
        </div>
        <div class="informations">
          <span class="categorie">Action</span>
          <h4 class="lieu">Nom de la maison</h4>
          <a class="bouton" href="details.php"><i class="fa fa-add"></i></a>
        </div>
      </div>
    </div>
  </div>

  <footer>
    <div class="espaceur">
      <br><br>
      <center>
        <p>Bienvenue dans notre site internet de location des maisons </p>
      </center>
    </div>
  </footer>


</body>

</html>