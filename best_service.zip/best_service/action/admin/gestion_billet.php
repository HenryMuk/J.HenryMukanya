<?php
require('database.php');

if(isset($_POST["mettre_a_jour"]))
{
    
    $NombreClassique = $_POST["NombreClassique"];
    $NombreSilver = $_POST["NombreSilver"];
    $NombreGold = $_POST["NombreGold"];

    $NombreTotal = $NombreClassique + $NombreSilver + $NombreGold;

    $InsertBillet = $My_data_base->prepare("UPDATE billet SET NombreTotal = ? ,NombreClassique = ? ,NombreSilver = ? ,NombreGold = ? WHERE idEvent=?");
    $InsertBillet->execute(array($NombreTotal,$NombreClassique,$NombreSilver,$NombreGold,$idRecup));

    $InserEventBillet = $My_data_base->prepare("UPDATE evenement SET NombreTotal = ?, NombreRestant = ? WHERE id=?");
    $InserEventBillet->execute(array($NombreTotal,$NombreTotal,$idRecup));

    header('Location: admin.php');

   
}
    
    
   


?>