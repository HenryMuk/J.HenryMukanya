<?php

require('database.php');

$statut1 = "a venir";

$RecupEventAvenir = $My_data_base->prepare("SELECT * FROM evenement WHERE statut = ?");
$RecupEventAvenir->execute(array($statut1));

$statut2 = "recent";

$RecupEventRecent = $My_data_base->prepare("SELECT * FROM evenement WHERE statut = ?");
$RecupEventRecent->execute(array($statut2));

?>