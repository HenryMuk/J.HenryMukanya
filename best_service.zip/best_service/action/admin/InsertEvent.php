<?php

require('database.php');


if(isset($_POST["ajouter"]))
{

    $type = $_POST["type"];
    $titre = $_POST["titre"];
    $date = $_POST["date"];
    $statut = "a venir";

    $fileName = $_FILES['image']['name'];

    if($fileName != NULL)
    {
        $fileSize = $_FILES['image']['size'];
        $tmpName = $_FILES['image']['tmp_name'];
    
        $ValidExtension = ['png', 'jpg', 'jpeg'];
        $imageExtension = explode('.', $fileName);
        $imageExtension = strtolower(end($imageExtension));
    
        if(!in_array($imageExtension, $ValidExtension))
        {
            echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
        }
        else if($fileSize > 1000000)
        {
            echo '<script>alert("Fichier trop lourd ");</script>';
        }
        else
        {
            $newImageName = uniqid();
            $newImageName .= '.' . $imageExtension;
    
            move_uploaded_file($tmpName, 'images/'. $newImageName);
        }
            
            $InsertEvent = $My_data_base->prepare('INSERT INTO evenement(type,titre,date,image,statut) VALUES(?,?,?,?,?)');
            $InsertEvent->execute(array($type,$titre,$date,$newImageName,$statut));

            $RecupEvent = $My_data_base->prepare("SELECT * FROM evenement WHERE titre = ?");
            $RecupEvent->execute(array($titre));

            $RecupEventid = $RecupEvent->fetch();
            
            $evenement_id = $RecupEventid['id'];


            $InsertBillet = $My_data_base->prepare('INSERT INTO billet (idEvent) VALUES(?)');
            $InsertBillet->execute(array($evenement_id));
    
            header('Location: admin.php');
    
           
    }
   

    
    else{
        $Message = "Veuiller selectionner une image d'affiche";
    }

}


?>