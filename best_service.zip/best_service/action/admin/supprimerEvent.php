<?php

require('database.php');


if(isset($_GET["id"]))
{
    $id = $_GET['id'];
  
    $statut = "recent";

    $InsertEvent = $My_data_base->prepare('UPDATE evenement SET statut = ? WHERE id=?');
    $InsertEvent->execute(array($statut,$id));

    header('Location: ../../admin.php');

}



?>