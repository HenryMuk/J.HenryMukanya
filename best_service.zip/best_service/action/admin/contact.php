<?php

require('database.php');

$RecupContact = $My_data_base->query("SELECT * FROM contact");

?>