<?php

require('database.php');

$idRecup = $_GET['id'];

$RecupBilletGestion = $My_data_base->prepare("SELECT * FROM billet WHERE idEvent = ?");
$RecupBilletGestion->execute(array($idRecup));

$billets = $RecupBilletGestion->fetch();

$classique = $billets["NombreClassique"];
$silver = $billets["NombreSilver"];
$gold = $billets["NombreGold"];



?>