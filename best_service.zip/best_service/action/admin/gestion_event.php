<?php

require('database.php');


if(isset($_POST["mettre_a_jour"]))
{
    $id = $_GET['id'];
    $type = $_POST["type"];
    $titre = $_POST["titre"];
    $date = $_POST["date"];
    $fileName = $_FILES['image']['name'];
    
    if($fileName != NULL)
    {
        $fileSize = $_FILES['image']['size'];
        $tmpName = $_FILES['image']['tmp_name'];
    
        $ValidExtension = ['png', 'jpg', 'jpeg'];
        $imageExtension = explode('.', $fileName);
        $imageExtension = strtolower(end($imageExtension));
    
        if(!in_array($imageExtension, $ValidExtension))
        {
            echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
        }
        else if($fileSize > 1000000)
        {
            echo '<script>alert("Fichier trop lourd ");</script>';
        }
        else
        {
            $image = uniqid();
            $image .= '.' . $imageExtension;
    
            move_uploaded_file($tmpName, 'images/'. $image);
        }

        $InsertEvent = $My_data_base->prepare('UPDATE evenement SET type = ? ,titre = ?,date = ?,image = ? WHERE id=?');
        $InsertEvent->execute(array($type,$titre,$date,$image,$id));

        header('Location: admin.php');

        
    
    }
    
    $InsertEvent = $My_data_base->prepare('UPDATE evenement SET type = ? ,titre = ?,date = ? WHERE id=?');
    $InsertEvent->execute(array($type,$titre,$date,$id));

    header('Location: admin.php');

    
}


?>