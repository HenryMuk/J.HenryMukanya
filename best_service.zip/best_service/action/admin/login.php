<?php
require('database.php');

if(isset($_POST["connexion"]))
{

    $nom = ($_POST["nom"]);
    $code = ($_POST["code"]);
    
    $Verif = $My_data_base->prepare("SELECT * FROM admin WHERE nom = ?");
    $Verif->execute(array($nom));

    if($Verif->rowCount() > 0)
    {
        $admin = $Verif->fetch();
      
        if($code == $admin["code"])
        {
            header('Location: admin.php');
        }
        else
        {
            $Message = "Le code d'authentification est incorrect";
        }   
    }
    else
    {
        $Message = "Votre nom d'utilisateur est incorrect";
    }
   
    

   
}

?>