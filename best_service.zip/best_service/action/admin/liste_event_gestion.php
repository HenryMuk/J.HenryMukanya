<?php

require('database.php');

$statut1 = "a venir";

$RecupEventGestion = $My_data_base->prepare("SELECT * FROM evenement WHERE statut = ?");
$RecupEventGestion->execute(array($statut1));

$evenement = $RecupEventGestion->fetch();

$type = $evenement['type'];
$titre = $evenement['titre'];
$date = $evenement['date'];

?>