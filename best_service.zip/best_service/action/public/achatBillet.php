<?php

require('database.php');


if(isset($_POST["payer"]))
{
    $id = $_GET["id"];
    $typeBillet = $_POST["typeBillet"];
    $nombre = $_POST["nombre"];


    $RecupBillet = $My_data_base->prepare("SELECT * FROM billet WHERE idEvent=?");
    $RecupBillet->execute(array($id));

    $billet = $RecupBillet->fetch();
    
    $classique = $billet["NombreClassique"];
    $silver = $billet["NombreSilver"];
    $gold = $billet["NombreGold"];

    if($typeBillet == "classique")
    {
        $classique =  $classique - $nombre; 
    }
    else if($typeBillet == "silver")
    {
        $silver =  $silver - $nombre; 
    }
    else
    {
        $gold =  $gold - $nombre; 
    }

    $NombreRestant = $classique + $silver + $gold;


    $MAJBillet = $My_data_base->prepare("UPDATE billet SET NombreClassique = ? , NombreSilver = ?, NombreGold = ?  WHERE idEvent=?");
    $MAJBillet->execute(array($classique,$silver,$gold,$id));

    $InserEventBillet = $My_data_base->prepare("UPDATE evenement SET NombreRestant = ? WHERE id=?");
    $InserEventBillet->execute(array($NombreRestant,$id));
    header('Location: service.php');

    
   
}


?>