<?php

require('database.php');

$RecupBillet = $My_data_base->query("SELECT * FROM billet");

?>