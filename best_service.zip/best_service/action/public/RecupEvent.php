<?php

require('database.php');

$statut = "a venir";

$RecupEvent = $My_data_base->prepare("SELECT * FROM evenement WHERE statut = ?");
$RecupEvent->execute(array($statut));

?>