<?php

require('database.php');


if(isset($_POST["contacter"]))
{

    $nom = $_POST["nom"];
    $email = $_POST["email"];
    $telephone = $_POST["telephone"];
    $message = $_POST["message"];
  
    
    $InsertContact = $My_data_base->prepare('INSERT INTO contact(nom, email, telephone, message) VALUES(?,?,?,?)');
    $InsertContact->execute(array($nom, $email, $telephone, $message));

    header('Location: index.php');

   
}


?>