<?php

require('database.php');

    if(isset($_GET['id']))
    {
        $idEvent = $_GET['id'];
    
        $RecupBilletGestion = $My_data_base->prepare("SELECT * FROM billet WHERE idEvent=?");
        $RecupBilletGestion->execute(array($idEvent));

        $billet = $RecupBilletGestion->fetch();

        $idRecupEvent = $billet["idEvent"];

        $classique = $billet["NombreClassique"];
        $silver = $billet["NombreSilver"];
        $gold = $billet["NombreGold"];

    }
    
 



?>