<?php
require("action/public/achatBillet.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="formulaire.css">
</head>
<body>
<?php if (isset($Message)): ?>
                <div style="width:100%;" class="alert alert-success alert-dismissible fade show m-auto" role="alert">
                    <?php echo $Message; ?>
                </div>

<?php endif; ?>

    <form action="" method="post" enctype="multipart/form-data">
    <h2>Formulaire de paiement</h2>

    <div class="form-group">
        <label for="num_carte">Numéro de carte :</label>
        <input type="text" id="num_carte" name="num_carte" required>
    </div>

    <div class="form-group">
        <label for="nom_titulaire">Nom du titulaire :</label>
        <input type="text" id="nom_titulaire" name="nom_titulaire" required>
    </div>

    <div class="form-group">
        <label for="date_expiration" >Date d'expiration</label>
        <input type="date" id="date_expiration" name="date_expiration" style="height:40px;border-radius:10px;" required>
    </div>

    <div class="form-group">
        <select name="typeBillet" id="" style="height:40px;border-radius:15px;" required>
        <option disabled selected>Confirmer votre billet</option>
        <option value="classique">Classique</option>
        <option value="silver">Silver</option>
        <option value="gold">Gold</option>
        </select>
    </div>

    <div class="form-group">
        <label for="nombre">Nombre :</label>
        <input type="text" id="nombre" name="nombre" required>
    </div>

    <button type="submit" name="payer">Payer</button>
</form>
</body>
</html>