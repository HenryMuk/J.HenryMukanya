<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>BEST SERVICE</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bo.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.php">
            <span>
              BEST SERVICE
            </span>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
              <ul class="navbar-nav  ">
                <li class="nav-item active">
                  <a class="nav-link" href="index.php"> Acceuil<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="service.php"> SERVICE</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="contact.php"> Contact</a>
                </li>
              </ul>
              <div class="user_option">
                <form class="form-inline my-2 my-lg-0 ml-0 ml-lg-4 mb-3 mb-lg-0">
                  <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit"></button>
                </form>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->

    <!-- slider section -->
    <section class=" slider_section position-relative">
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h3>
                      Ciné
                    </h3>
                    <h2>
                      Concert
                    </h2>
                    <h1>
                      BEST SERVICE
                    </h1>
                    <p>
                      Bienvenue dans best service. le site d'achat de billet en ligne pour vous. grace à ce site vous n'aurez plus à vous déplacez ou faire la file d'attente pour vous procurez un billet.
                      Vous recherchez des billets pour un événement, un spétacle ou une activité ? Vous êtes au bon endroit! Notre billeterie en ligne vous permet de réserver vos places rapidement et simplement.
                      Que vous soyez à la recherche de billets pour un concert, un match de sport, un spectacle ou une exposition, vous trouverez tout ce dont vous avez besoin sur notre plateforme.
                      Notre équipe met à jour régulièrement notre catalogue avec les meilleurs offres disponibles dans votre région.  Avec notre billeterie en ligne, bénéficiez de nombreux avantages.
                      Alors n'attendez plus, rendez-vous sur notre billeterie en ligne dès maintenant pour découvrir tous nos événements et réserver vos places.
                    </p>
                    <div class="">
                      <a href="contact.php">
                        Nous contactez
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h3>
                      Ciné
                    </h3>
                    <h2>
                      Concert
                    </h2>
                    <h1>
                      BEST SERVICE
                    </h1>
                    <p>
                      Vous recherchez des billets pour un événement, un spétacle ou une activité ? Vous êtes au bon endroit! Notre billeterie en ligne vous permet de réserver vos places rapidement et simplement.
                    </p>
                    <div class="">
                      <a href="">
                        Nous contactez
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h3>
                      Ciné
                    </h3>
                    <h2>
                      Concert
                    </h2>
                    <h1>
                      BEST SERVICE
                    </h1>
                    <p>
                      Que vous soyez à la recherche de billets pour un concert, un match de sport, un spectacle ou une exposition, vous trouverez tout ce dont vous avez besoin sur notre plateforme.
                    </p>
                    <div class="">
                      <a href="">
                        Nous contactez
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h3>
                      Ciné
                    </h3>
                    <h2>
                      Concert
                    </h2>
                    <h1>
                      BEST SERVICE
                    </h1>
                    <p>
                      Notre équipe met à jour régulièrement notre catalogue avec les meilleurs offres disponibles dans votre région.  Avec notre billeterie en ligne, bénéficiez de nombreux avantages.
                    </p>
                    <div class="">
                      <a href="">
                        Nous contactez
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h3>
                      Ciné
                    </h3>
                    <h2>
                      Concert
                    </h2>
                    <h1>
                      BEST SERVICE
                    </h1>
                    <p>
                      Alors n'attendez plus, rendez-vous sur notre billeterie en ligne dès maintenant pour découvrir tous nos événements et réserver vos places.
                    </p>
                    <div class="">
                      <a href="">
                        Nous contactez
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
        </ol>
      </div>
    </section>
    <!-- end slider section -->
  </div>

  <!-- heathy section -->

  <section class="heathy_section layout_padding">
    <div class="container">

      <div class="row">
        <div class="col-md-12 mx-auto">
          <div class="detail-box">
            <h2>
              BIENVENU SUR NOTRE BILLETERIE EN LIGNE
            </h2>
            <p>
              Vous recherchez des billets pour un événement, un spétacle ou une activité ? Vous êtes au bon endroit! Notre billeterie en ligne vous permet de réserver vos places rapidement et simplement. Que vous soyez à la recherche de bollets pour un concert, un match de sport, un spectacle ou une exposition, vous trouverez tout ce dont vous avez besoin sur notre plateforme. Notre équipe met à jour régulièrement notre catalogue avec les meilleurs offres disponibles dans votre région. 
            </p>
            <div class="btn-box">
              <a href="lire.php">
                LIRE PLUS
              </a>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

  <!-- end heathy section -->

  <!-- footer section -->
  <footer class="container-fluid footer_section">
    <p>
      &copy; <a href="login_admin.php">2024 All Rights Reserved.</a>
    </p>
  </footer>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>

</body>

</html>