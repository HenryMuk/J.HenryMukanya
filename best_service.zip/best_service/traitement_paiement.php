<?php
// Récupération des données du formulaire
$num_carte = $_POST['num_carte'];
$nom_titulaire = $_POST['nom_titulaire'];
$date_expiration = $_POST['date_expiration'];
$cryptogramme = $_POST['cryptogramme'];
$montant = $_POST['montant'];

// Vérification des données 
if (empty($nim_carte)  ||
empty($nom_titulaire)  ||
empty($date_expiration)  ||
empty($cryptogramme)  ||
empty($montant)) {
    echo "Veuillez remplir tous les champs.";
    exit;
}

// Connexion à un système de paiement 
(exemple avec stripe)
require 'vendor/autoload.php';
\Stripe\Stripe::setApikey('votre_clé_secrète_stripe');

try {
    $payment_intent =
    \Stripe\PaymentIntent::create(['amount' => $montant * 100, 
    // Montant en centimes 
    'current' => 'eur',
    'payment_metho_types' => ['card'],
]);

$client_secret = $payment_intent->client_secret;

// Renvoi du client_secret vers le frontend pour finaliser le paiement
echo json_encode(['client_secret' => $client_secret]);
} catch
(\Stripe\Exception\ApiErrorExeption $e) {
    echo "Erreur de paiement : " . $e->getMessage();
}