<?php
  require('action/admin/liste_billet_gestion.php');
  require('action/admin/gestion_billet.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Billetterie - Administration</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
  <style>
    /* Définition de la charte graphique */
    :root {
      --primary-color: #007bff;
      --secondary-color: #6c757d;
      --background-color: #f8f9fa;
      --font-family: 'Roboto', sans-serif;
    }

    body {
      font-family: var(--font-family);
      background-color: var(--background-color);
      margin: 0;
      padding: 0;
    }

    .header {
      background-color: var(--primary-color);
      color: #fff;
      padding: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .header h1 {
      margin: 0;
    }

    .nav {
      display: flex;
      list-style-type: none;
      margin: 0;
      padding: 0;
    }

    .nav li {
      margin-left: 20px;
    }

    .nav li a {
      color: #fff;
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s;
    }

    .nav li a:hover {
      color: #dee2e6;
    }

    .content {
      padding: 20px;
    }

    .card {
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 5px;
    }

    .card h2 {
      margin-top: 0;
    }

    .button {
      background-color: var(--primary-color);
      color: #fff;
      border: none;
      padding: 10px 20px;
      text-decoration: none;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .button:hover {
      background-color: #0056b3;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #dee2e6;
    }

    th {
      background-color: var(--secondary-color);
      color: #fff;
    }

    tr:hover {
      background-color: #f1f1f1;
    }
  </style>
</head>
<body>
<?php if (isset($Message)): ?>
                <div style="width:100%;" class="alert alert-success alert-dismissible fade show m-auto" role="alert">
                    <?php echo $Message; ?>
                </div>

<?php endif; ?>
  <header class="header">
    <h1>Billetterie - Administration</h1>
    <nav>
      <ul class="nav">
      <li><a href="admin.php">Tableau de bord</a></li>
      <li><a href="admin_contact.php">Contact</a></li>
      </ul>
    </nav>
  </header>

  <div class="content">
    <div class="card">
      <h2>Billetterie</h2> 
      <table>
        <thead>
          <tr>
            <th>Classique</th>
            <th>Silver</th>
            <th>Gold</th>
           
            <th>Actions</th>
          </tr>
        </thead>
        <form action="" method="post" enctype="multipart/form-data">
        <tbody>
         
          <tr>
            <td><input type="text" name="NombreClassique"  value="<?=$classique;?>"></td>
            <td><input type="text" name="NombreSilver" value="<?=$silver;?>"></td>
            <td><input type="text" name="NombreGold"  value="<?=$gold;?>"></td>
            
            <td><button type="submit" name="mettre_a_jour" class="button">Mettre à jour</button></td>
          </tr>
          </form>
         
        </tbody>
      </table>
    </div>

    
  </div>
</body>
</html> 