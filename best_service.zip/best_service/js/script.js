//infromations sur les billets 
let totalBillets = 100;
let billetResttants = 100;
let totaVentes = 0;

//Fonction d'achat de billet
function achatBillet(){
    //Vérifier la disponibilité 
    if (billetResttants > 0){
        //Réduire le nombre de billets restants 
        billetRestants--;
        //Mettre à jour le total des ventes 
        totalVentes++;
        console.log('Achat réussi ! il reste $ {billetResttants}billets disponibles.');
            }else{
                console.log("Désolé, il n'y a plus de billets disponibles")
    }
}

//Exemple d'utilistion 
achatBillet();//Achat réussi ! il rsete 99 billets disponibles.
achatBillet();//Achat réussi ! il reste 98 billets disponibles.
achatBillet();//Désolé, il n'y a plus de billets disponibles.
