<?php
	session_start();
	require('actions/users/infosuser.php');
?>


<!DOCTYPE html>
<?php
    include"includes/headprofil.php";
 
    include"includes/navbarprofil.php";
?>
<html lang="en">

<body>
    

<br><br><br><br><br><br><br>

<div class="section">
		<div class="container">
			

							<?php
							
							if(in_array($_SESSION['role'], [0,3])){ 

								$role = "Membre";	
							}
							else if(in_array($_SESSION['role'], [4]))
							{
								$role = "Administrateur";	
							}
							?>
								
				
											<div class="poster">

											</div>
										<form method="POST" action="">

											<div class="upload">
												<img src="images/<?=$_SESSION['photo'];?>" alt="" id="image">
													

													



											</div>
											<div class="form-group">
												<label class="form-style" > <?=$_SESSION['username'];?></label>
												<i class="input-icon uil uil-user"></i>
											</div>	
											<div class="form-group mt-2">
												<label class="form-style" > <?=$_SESSION['name'];?></label>
												<i class="input-icon uil uil-user"></i>
											</div>	
                      						<div class="form-group mt-2">
												<label class="form-style" > <?=$_SESSION['email'];?></label>
												<i class="input-icon uil uil-at"></i>
											</div>

											<div class="form-group mt-2">
												<label class="form-style" > <?=$role;?></label>
												<i class="input-icon uil uil-lock-alt"></i>
											</div>
											<div class="form-group mt-2">
											<label style="height:150px;" class="form-style" > <?=$_SESSION['description'];?></label>
												<i class="input-icon uil uil-user"></i>
											</div>
											
										
                                            <a  href="mes_questions.php" class="btn mt-4" >Gérer mes questions </a>
                                            <a  href="gestionduprofile.php?id=<?= $_SESSION['id']; ?>" class="btn mt-4" >Gérer mon profil </a>
											</form>
											</div>

									

</div>
</div>


</body>
</html>