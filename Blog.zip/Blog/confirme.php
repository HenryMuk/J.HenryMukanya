<?php 

require('actions/users/signin.php');?>

<!doctype html>
<?php  
    include"includes/headConnect.php";
?>
<html lang="en">
<body>

<div class="section">
		<div class="container">
			<div class="row full-height justify-content-center">
				<div class="col-12 text-center align-self-center py-5">
					<div class="section pb-5 pt-5 pt-sm-2 text-center">
						<h6 class="mb-0 pb-3"><span> Autorisé </span></h6>
			          	<input class="checkbox" type="checkbox" id="reg-log" name="reg-log"/>
			          	<label for="reg-log"></label>
						<div class="card-3d-wrap mx-auto">
							<div class="card-3d-wrapper">
								<div class="card-front">
									<div class="center-wrap">
										<div class="section text-center">
											<h4 class="mb-4 pb-3"> COMPTE VERIFIÉ ! </h4>
										<form method="POST" action="">

											
											
												<label  style="height:120px;" class="form-style" >Votre compte a été vérifié et autorisé à accéder au site , veuillez à présent regagner le site </label>
												<i class=""></i>
												<a href="index.php" class="btn mt-4">
													Accéder au site
												</a>
											</div>
											
										</form>
	





                                        </div>
			      					</div>
			      				</div>
			      			</div>
			      		</div>
			      	</div>
		      	</div>
	      	</div>
	    </div>
	</div>

</body>
</html>