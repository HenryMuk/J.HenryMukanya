<?php
session_start();
require('actions/users/gestionUsers.php');

?>

<!DOCTYPE html>
<?php
    include"includes/headprofil.php";
 
    include"includes/navbarprofil.php";
?>
<html lang="en">

<body>
    

<br><br><br><br><br><br><br>

<div class="section">
		<div class="container">
			
								
				<div class="poster">

				
											
										<form method="POST" action="" enctype="multipart/form-data">

											<div class="upload">
												<img src="images/<?=$_SESSION['photo']; ?>" alt="" id="image">
													
												



											</div>
											<div class="form-group">
                                            <input type="text" class="form-style" name="username" value="<?= $_SESSION['username']; ?>" required>
												<i class="input-icon uil uil-user"></i>
											</div>	
											<div class="form-group mt-2">
                                            <input type="tel" class="form-style" placeholder="Name" name="name" value="<?= $_SESSION['name']; ?>" required>
												<i class="input-icon uil uil-user"></i>
											</div>	
                      						<div class="form-group mt-2">
                                              <input type="email" class="form-style" placeholder="Email" name="email" value="<?= $_SESSION['email']; ?>" required>
												<i class="input-icon uil uil-at"></i>
											</div>
											<div class="form-group mt-2">
                                              <textarea type="text" class="form-style" style="height:150px;" placeholder="Description" name="description"  ><?= $_SESSION['description']; ?> </textarea>
												<i class="input-icon uil uil-user"></i>
											</div>
											<div class="form-group mt-2">
                                              <input type="file" class="form-style" placeholder="" name="image" id="image" >
												<i class="input-icon uil uil-camera"></i>
											</div>
											
											<input type="submit" name="validate" class="btn mt-4" value="Validate">
											</form>
				</div>

</div>
</div>









</body>
</html>