<?php
require('actions/database.php');

$getAllUsers = $My_data_base->query('SELECT id, username, name, email, role, photo, description FROM users ORDER BY id DESC');

if(isset($_GET['search']) AND !empty($_GET['search'])){


    $usersSearch = $_GET['search'];

    $getAllUsers = $My_data_base->query('SELECT id, username, name, email, role, photo FROM users WHERE username LIKE "%'.$usersSearch.'%" ORDER BY id DESC');

}