<?php
$servername = "localhost";
$user = "HenryDev";
$password = "jackyhenry";

try{
    $My_data_base = new PDO("mysql:host=$servername;dbname=samplecoding", $user, $password);
}catch(Exception $e)
{
    die("Une erreur est survenue..." .$e->getMessage());

}



//Vérifier si l'utilisateur est authentifié au niveau du site
session_start();
if(!isset($_SESSION['auth'])){
    header('Location: ../../login.php');
}



//Vérifier si l'id est rentré en paramètre dans l'URL
if(isset($_GET['id']) AND !empty($_GET['id'])){

    //L'id de la question en paramète
    $idOfTheUser = $_GET['id'];

    //Vérifier si la question existe
    $checkIfUsersExists = $My_data_base->prepare('SELECT username FROM users WHERE id = ?');
    $checkIfUsersExists->execute(array($idOfTheUser));

    if($checkIfUsersExists->rowCount() > 0){

        //Récupérer les infos de la question
        $usersInfos = $checkIfUsersExists->fetch();
        if(in_array($_SESSION['role'], [4])){

            //Supprimer la question en fonction de son id rentré en paramètre
            $deleteThisUser = $My_data_base->prepare('DELETE FROM users WHERE id = ?');
            $deleteThisUser->execute(array($idOfTheUser));

        

            //Rediriger l'utilisateur vers ses questions
            header('Location: ../../admin.php');

        }else{
            echo "Vous n'avez pas le droit de supprimer un utilisateur !";
        }

    }else{
        echo "Aucune question n'a été trouvée";
    }


}else{
    echo "Aucune question n'a été trouvée";
}