<?php

//Vérifier si l'utilisateur est authentifié au niveau du site
session_start();
if(!isset($_SESSION['auth'])){
    header('Location: ../../login.php');
}

require('../database.php');

//Vérifier si l'id est rentré en paramètre dans l'URL
if(isset($_GET['id']) AND !empty($_GET['id'])){

    //L'id de la question en paramète
    $idOfTheAnswers = $_GET['id'];

    //Vérifier si la question existe
    $checkIfAnswersExists = $My_data_base->prepare('SELECT id_auteur FROM answers WHERE id = ?');
    $checkIfAnswersExists->execute(array($idOfTheAnswers));

    if($checkIfAnswersExists->rowCount() > 0){

        //Récupérer les infos de la question
        $answerssInfos = $checkIfAnswersExists->fetch();
        if(in_array($_SESSION['role'], [4])){

            //Supprimer la question en fonction de son id rentré en paramètre
            $deleteThisQuestion = $My_data_base->prepare('DELETE FROM answers WHERE id = ?');
            $deleteThisQuestion->execute(array($idOfTheAnswers));

            //Rediriger l'utilisateur vers ses questions
            header('Location: ../../admin.php');

        }else{
            echo "Vous n'avez pas le droit de supprimer une question qui ne vous appartient pas !";
        }

    }else{
        echo "Aucune question n'a été trouvée";
    }


}else{
    echo "Aucune question n'a été trouvée";
}