<?php
require('actions/database.php');

$getAllSupports = $My_data_base->query('SELECT id, support_auteur, support_email, content FROM support ORDER BY id DESC LIMIT 0,5');

if(isset($_GET['search']) AND !empty($_GET['search'])){


    $usersSearch = $_GET['search'];

    $getAllSupports = $My_data_base->query('SELECT id, support_auteur, support_email, content FROM support WHERE support_auteur LIKE "%'.$usersSearch.'%" ORDER BY id DESC');

}