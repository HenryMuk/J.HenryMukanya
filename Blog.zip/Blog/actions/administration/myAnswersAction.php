<?php

require('actions/database.php');

$getAllMyAnswers = $My_data_base->prepare('SELECT id, id_auteur, pseudo_auteur, id_question, contenu, photo_auteur FROM answers WHERE id_auteur = ? ORDER BY id DESC');
$getAllMyAnswers->execute(array($_SESSION['id']));