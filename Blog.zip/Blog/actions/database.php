<?php

$servername = "localhost";
$user = "HenryDev";
$password = "jackyhenry";

try{
    $My_data_base = new PDO("mysql:host=$servername;dbname=samplecoding", $user, $password);
}catch(Exception $e)
{
    die("Une erreur est survenue..." .$e->getMessage());

}

?>