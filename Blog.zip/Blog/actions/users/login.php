<?php
session_start();
require('actions/database.php');

if(isset($_POST["validate"]))
{

    $username = htmlspecialchars($_POST["username"]);
    $email = htmlspecialchars($_POST["email"]);
    $mdp = htmlspecialchars($_POST["mdp"]);
    
    $VerifIfUserExist = $My_data_base->prepare("SELECT * FROM users WHERE username = ? AND email = ?");
    $VerifIfUserExist->execute(array($username, $email));

    if($VerifIfUserExist->rowCount() > 0)
    {
        $UserInfos = $VerifIfUserExist->fetch();
      
        if(password_verify($mdp, $UserInfos["mdp"]))
        {
            $_SESSION['auth'] = true;
            $_SESSION['id'] = $UserInfos['id'];
            $_SESSION['username'] = $UserInfos['username'];
            $_SESSION['name'] =  $UserInfos['name'];
            $_SESSION['email'] =  $UserInfos['email'];
            $_SESSION['role'] =  $UserInfos['role'];
            $_SESSION['description'] =  $UserInfos['description'];
            $_SESSION['photo'] =  $UserInfos['photo'];
            
            header('Location: index.php');
        }
        else
        {
            echo '<script>alert("Le mot de passe est incorrect");</script>';
        }   
    }
    else
    {
        echo '<script>alert("Votre nom d\'utilisateur ou votre email est incorrect");</script>';
    }
   
    

   
}

?>