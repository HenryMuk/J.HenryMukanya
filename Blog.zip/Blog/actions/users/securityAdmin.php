<?php
if(!(in_array($_SESSION['role'], [4])))
{
    header('Location: index.php');
}

?>