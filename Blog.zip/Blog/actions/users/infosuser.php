<?php

require('actions/database.php');

//Récupérer l'identifiant de l'utilisateur
if(isset($_GET['id']) AND !empty($_GET['id'])){

    //L'id de l'utilisateur
    $idOfUser = $_GET['id'];

    //Vérifier si l'utilisateur existe
    $checkUser = $My_data_base->prepare('SELECT username, name, email, role, photo,description FROM users WHERE id = ?');
    $checkUser->execute(array($idOfUser));

        
        //Récupérer toutes les données de l'utilisateur
        $usersInfos = $checkUser->fetch();

        $user_username = $usersInfos['username'];
        $user_name = $usersInfos['name'];
        $user_email = $usersInfos['email'];
        $user_photo = $usersInfos['photo'];
        $user_description = $usersInfos['description'];
        $user_role = $usersInfos['role'];


        //Récupérer toutes les questions publiées par l'utilisateur
        $getHisQuestions = $My_data_base->prepare('SELECT * FROM questions WHERE id_auteur = ? ORDER BY id DESC');
        $getHisQuestions->execute(array($idOfUser));



}else{
    $errorMsg = "Aucun utilisateur trouvé";
}