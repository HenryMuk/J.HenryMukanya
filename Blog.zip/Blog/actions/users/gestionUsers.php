<?php

require('actions/database.php');

//Validation du formulaire
if(isset($_POST['validate'])){

        //Les données à faire passer dans la requête
        $new_username = htmlspecialchars($_POST['username']);
        $new_name = htmlspecialchars($_POST['name']);
        $new_email = htmlspecialchars($_POST['email']);
        $new_description = htmlspecialchars($_POST['description']);
        $fileName = $_FILES['image']['name'];

        if($_FILES["image"]["name"] != NULL)
        {
            $fileSize = $_FILES['image']['size'];
            $tmpName = $_FILES['image']['tmp_name'];

            $ValidExtension = ['png', 'jpg', 'jpeg'];
            $imageExtension = explode('.', $fileName);
            $imageExtension = strtolower(end($imageExtension));

            if(!in_array($imageExtension, $ValidExtension))
            {
                echo '<script>alert("Ce type de fichier n\'est pas prit en charge");</script>';
            }
            else if($fileSize > 1000000)
            {
                echo '<script>alert("Fichier trop lourd ");</script>';
            }
            else
            {
                $newImageName = uniqid();
                $newImageName .= '.' . $imageExtension;

                move_uploaded_file($tmpName, 'images/'. $newImageName);
            }

             //Modifier les informations de la question qui possède l'id rentré en paramètre dans l'URL
            $ModifUser = $My_data_base->prepare('UPDATE users SET username = ?, name = ?, email = ?, photo = ?, description = ?  WHERE id = ?');
            $ModifUser->execute(array($new_username, $new_name, $new_email, $newImageName,$new_description, $_SESSION['id']));


            $ModifPhotoAuteur = $My_data_base->prepare('UPDATE questions SET photo_auteur = ? WHERE id_auteur = ?');
            $ModifPhotoAuteur->execute(array($newImageName, $_SESSION['id']));


            //Redirection vers la page d'affichage des questions de l'utilisateur
            $RecupUser = $My_data_base->prepare("SELECT * FROM users WHERE username = ?");
            $RecupUser->execute(array($new_username));

            $UserInfos = $RecupUser->fetch();

            $_SESSION['username'] = $UserInfos['username'];
            $_SESSION['name'] =  $UserInfos['name'];
            $_SESSION['email'] =  $UserInfos['email'];
            $_SESSION['description'] =  $UserInfos['description'];
            $_SESSION['photo'] =  $UserInfos['photo'];

            header('Location: profile.php');
            
            
        }
        else
        {   
            
            $ModifUser = $My_data_base->prepare('UPDATE users SET username = ?, name = ?, email = ?, description=?  WHERE id = ?');
            $ModifUser->execute(array($new_username, $new_name, $new_email,$new_description, $_SESSION['id']));

            //Redirection vers la page d'affichage des questions de l'utilisateur
            $RecupUser = $My_data_base->prepare("SELECT * FROM users WHERE username = ?");
            $RecupUser->execute(array($new_username));

            $UserInfos = $RecupUser->fetch();

            $_SESSION['username'] = $UserInfos['username'];
            $_SESSION['name'] =  $UserInfos['name'];
            $_SESSION['email'] =  $UserInfos['email'];
            $_SESSION['description'] =  $UserInfos['description'];
            $_SESSION['photo'] =  $UserInfos['photo'];

                header('Location: profile.php');
            
        }
       
         
}