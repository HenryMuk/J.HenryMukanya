<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';



require('actions/database.php');

$mail = new PHPMailer(true);

if(isset($_POST["validate"]))
{

    $username = htmlspecialchars($_POST["username"]);
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $mdp = htmlspecialchars($_POST["mdp"]);
    $photo = "user1.png";
    $description = "Pas de description...";
    $role = 0;

    if(preg_match('/^(?=.*?[A-Z])(?=.*?[0-9]).{8,}$/', $mdp))
    {
        $mdp = password_hash($_POST["mdp"], PASSWORD_DEFAULT);

        $VerifIfUserExist = $My_data_base->prepare("SELECT username FROM users WHERE username = ?");
        $VerifIfUserExist->execute(array($username));

            if($VerifIfUserExist->rowCount() == 0)
            {

                    $InsertUser = $My_data_base->prepare('INSERT INTO users(username, name, email, mdp, role, photo,description) VALUES(?,?,?,?,?,?,?)');
                    $InsertUser->execute(array($username, $name, $email, $mdp, $role, $photo,$description));

                    $RecupUser = $My_data_base->prepare('SELECT id , username, name , email , role , photo , description FROM users WHERE username = ? AND name = ? AND email = ? AND role =? AND photo = ? AND description =?');
                    $RecupUser->execute(array($username, $name, $email, $role, $photo , $description));

                    $UserInfos = $RecupUser->fetch();

                    $_SESSION['auth'] = true;
                    $_SESSION['id'] = $UserInfos['id'];
                    $_SESSION['username'] = $UserInfos['username'];
                    $_SESSION['name'] =  $UserInfos['name'];
                    $_SESSION['email'] =  $UserInfos['email'];
                    $_SESSION['role'] =  $UserInfos['role'];
                    $_SESSION['photo'] =  $UserInfos['photo'];
                    $_SESSION['description'] =  $UserInfos['description'];
                

                    try
                    {
                                
                                $mail->IsSMTP();
                                $mail->Host = 'smtp.gmail.com';
                                $mail->SMTPAuth = true; 
            
                                $mail->SMTPOptions = array(
                                    'ssl' => array(
                                    'verify_peer' => false,
                                    'verify_peer_name' => false,
                                    'allow_self_signed' => true
                                    )
                                    );
                        
                                $mail->SMTPSecure = 'tls'; 
                                $mail->Port = '587';  
                                $mail->Username = 'SampleCodingManager@gmail.com';
                                $mail->Password = 'nrgoozhhpdfvghex';   
                                $mail->setFrom('SampleCodingManager@gmail.com');
                                $mail->AddAddress($email);
                        
                        //   $path = 'reseller.pdf';
                        //   $mail->AddAttachment($path);
                        
                                $mail->IsHTML(true);
                                
                            
                                $mail->Subject = "Validation du compte";
                                $mail->Body = 
                                "
                                Bienvenue $username sur nom du site <br> 
                                Nous espérons que vous trouverez la solution à tous vos problèmes informatiques sur nom du site <br>
                                Et / ou que vous serez à votre tour capable de venir en aide aux autres membres de nom du site <br><br>
                                Afin de confirmer votre compte et finaliser votre inscription , veuillez suivre le lien suivant : <br>
                                <a href='http://localhost/Les_Formes/Blog/confirme.php'>Confirmer mon compte</a>
                                

                                
                                ";
                                
                                $mail->send();
                            
                        
                    
                                header('Location: waiting.php');
            
                            
                    }catch(Exception $e){
                        echo $e->getMessage();
                    }
                
                        

                        

                
            }

            else
            {
                echo '<script>alert("Ce nom d\'utilisateur est déjà prit");</script>';
            }
    }
    else
    {
        echo '<script>alert("Veuillez fournir un mot de passe ayant toutes les caractéristiques demandées");</script>';
    }

    
    
    
   
    
}


?>