<?php

require('actions/database.php');

if(isset($_POST["validate"]))
{

    $content = nl2br(htmlspecialchars($_POST["content"]));
   
    
    $Insertsupport = $My_data_base->prepare('INSERT INTO support(id_auteur, support_auteur, support_email, content) VALUES(?,?,?,?)');
    $Insertsupport->execute(array($_SESSION['id'], $_SESSION['username'], $_SESSION['email'], $content));
    
   
    echo '<script>alert("Les informations ont bien été envoyées , notre équipe vous contactera d\'ici peu");</script>';
       
}

?>