<?php
require('actions/database.php');

if(isset($_POST['validate']))
{
    $titre = htmlspecialchars($_POST['titre']);
    $description = nl2br(htmlspecialchars($_POST['description']));
    $contenu = nl2br(htmlspecialchars($_POST['contenu']));
    $id_auteur = $_SESSION['id'];
    $pseudo_auteur = $_SESSION['username'];
    $date_publication = date('d/m/y');
    $code = nl2br(htmlspecialchars($_POST['code']));
    $photo_auteur = $_SESSION['photo'];
    
    
    

    $InsertQuestion = $My_data_base->prepare('INSERT INTO questions(titre, description, contenu,  id_auteur, pseudo_auteur, date_publication , code, photo_auteur) VALUES(?,?,?,?,?,?,?,?)');
    $InsertQuestion->execute(array($titre, $description, $contenu, $id_auteur, $pseudo_auteur, $date_publication, $code, $photo_auteur));
    
 

    header('Location: les_questions.php');
}

?>