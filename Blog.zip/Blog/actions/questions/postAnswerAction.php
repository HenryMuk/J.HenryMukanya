<?php

require('actions/database.php');

if(isset($_POST['validate'])){

    if(!empty($_POST['answer'])){

        $user_answer = nl2br(htmlspecialchars($_POST['answer']));

        $insertAnswer = $My_data_base->prepare('INSERT INTO answers(id_auteur, pseudo_auteur, id_question, contenu, photo_auteur)VALUES(?, ?, ?, ?, ?)');
        $insertAnswer->execute(array($_SESSION['id'], $_SESSION['username'], $idOfTheQuestion, $user_answer, $_SESSION['photo']));

    }

}