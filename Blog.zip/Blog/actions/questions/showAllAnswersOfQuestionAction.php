<?php

require('actions/database.php');

$getAllAnswersOfThisQuestion = $My_data_base->prepare('SELECT id, id_auteur, pseudo_auteur, id_question, contenu, photo_auteur FROM answers WHERE id_question = ? ORDER BY id DESC');
$getAllAnswersOfThisQuestion->execute(array($idOfTheQuestion)); 