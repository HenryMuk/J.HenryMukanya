<?php

require('actions/database.php');

$getAllMyQuestions = $My_data_base->prepare('SELECT id, titre, description, contenu, code FROM questions WHERE id_auteur = ? ORDER BY id DESC');
$getAllMyQuestions->execute(array($_SESSION['id']));