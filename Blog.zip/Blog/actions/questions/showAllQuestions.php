<?php
require('actions/database.php');

$getAllQuestions = $My_data_base->query('SELECT id, id_auteur, titre, description, pseudo_auteur, date_publication, photo_auteur FROM questions ORDER BY id DESC');

if(isset($_GET['search']) AND !empty($_GET['search'])){


    $usersSearch = $_GET['search'];

    $getAllQuestions = $My_data_base->query('SELECT id, id_auteur, titre, description, pseudo_auteur, date_publication, photo_auteur FROM questions WHERE titre LIKE "%'.$usersSearch.'%" ORDER BY id DESC');

}