<?php
	session_start();
	require('actions/users/infosuser.php');
?>


<!DOCTYPE html>
<?php
    include"includes/headprofil.php";
 
    include"includes/navbarprofilvisit.php";
?>
<html lang="en">

<body>
    

<br><br><br><br><br><br><br>

<div class="section">
		<div class="container">
			

							<?php
							
							if($user_role <= 3){ 

								$role = "Membre";	
							}
							else if($user_role >= 4)
							{
								$role = "Administrateur";	
							}
							?>
								
				
											
										<form method="POST" action="">

											<div class="upload">
												<img src="images/<?=$user_photo;?>" alt="" id="image">
													

													



											</div>
											<div class="form-group">
												<label class="form-style" > <?=$user_username;?></label>
												<i class="input-icon uil uil-user"></i>
											</div>	
											<div class="form-group mt-2">
												<label class="form-style" > <?=$user_name;?></label>
												<i class="input-icon uil uil-user"></i>
											</div>	
                      						<div class="form-group mt-2">
												<label class="form-style" > <?=$user_email;?></label>
												<i class="input-icon uil uil-at"></i>
											</div>
											<div class="form-group mt-2">
												<label class="form-style" > <?=$role;?></label>
												<i class="input-icon uil uil-lock-alt"></i>
											</div>
                                            <div class="form-group mt-2">
                                            <label style="height:150px;" class="form-style" > <?=$user_description;?></label>
												<i class="input-icon uil uil-user"></i>
											</div>

                                            <br>
                                            <br>

                                            <label class="form-style"  style="text-align:center; font-size:20px; ">Ci-dessous toutes les questions posées par l'utilisateur <?=$user_username;?> <?=$user_name;?></label>

                                            <?php
                while($question = $getHisQuestions->fetch()){ 
                    ?>

                        <div class="card">
                        <div class="card-header">
                            <?= $question['titre']; ?>
                        </div>
                        <div class="card-body">
                            <?= $question['description']; ?>
                        </div>
                        <div class="card-footer">
                            Posée le <?= $question['date_publication'];  ?>  <a class="" href="articles.php?id=<?= $question['id']; ?>"> Accéder à la question</a>
                        </div>
                    </div>
											

                                            <?php
                }

            
        ?>  


                                  
                                           
                                            <a  href="les_questions.php" class="btn mt-4" >Retour </a>

                                            <br>
                                            <br>
										
                                            </form>
											</div>

									

</div>
</div>


</body>
</html>