<?php
    require('actions/users/security.php');
    require('actions/questions/getInfosOfEditedQuestionAction.php');
    require('actions/questions/editQuestionAction.php');
?>
<!DOCTYPE html>
<html lang="en">
<?php
    include"includes/header.php";
    include"includes/navbarmodif.php";
    include"includes/navpublish.php";
?>
<body>
   

    <br><br><br><br><br><br>
    <div class="container">
         
        <?php 
            if(isset($question_content)){ 
                ?>
                <div class="poster">

                
                <form method="POST">
                    <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label"><strong style="color:#ffffff;">Titre de la question</strong> <strong style="color:red; font-size:25px;">*</strong></label>
                        <input type="text" class="form-control" name="title" value="<?= $question_title; ?>" required>
                    </div>
                    <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label"><strong style="color:#ffffff;">Description de la question</strong> <strong style="color:red; font-size:25px;">*</strong></label>
                        <textarea class="form-control" name="description"><?= $question_description; ?></textarea required>
                    </div>
                    <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label"><strong style="color:#ffffff;">Contenu de la question</strong> <strong style="color:red; font-size:25px;">*</strong></label>
                        <textarea type="text" class="form-control" name="content"><?= $question_content; ?></textarea required>
                    </div>

                    <button type="submit" class="btn btn-primary" name="validate">Modifier la question</button>
                </form>
                </div>
                <?php
            }
        ?>
        

    </div>
    

</body>
</html>