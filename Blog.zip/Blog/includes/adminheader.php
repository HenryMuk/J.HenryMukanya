


<nav class="navbar navbar-expand-lg">
                <div class="container">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                           
                            

                    <a style="text-transform: none; color:#03b8dc;" class="navbar-brand"  href="#">
                        <strong><span style="text-transform: none; color:#03b8dc;">Sample</span> Admin</strong>
                    </a>

                    <div class="d-lg-none">
                        <a href="sign-in.html" class="bi-person custom-icon me-3"></a>

                        <a href="product-detail.html" class="bi-bag custom-icon"></a>
                    </div>

                    <div class="responsive1" id="navbarNav">
                        <ul class="navbar-nav mx-auto">
                            

                            <li class="nav-item">
                                <a class="nav-link active" href="les_questions.php">Les questions</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link " href="usersforadmindj.php">Les utilisateurs</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link " href="support_for_admindj.php">Les supports</a>
                            </li>

                         

                            
                            

         
                        </ul>
                        
                    </div>
                </div>
            </nav>
