<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="" data-header-position="absolute" data-boxed-layout="full">
        
        <aside class="left-sidebar" style="background:#1f2029;" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
            <br><br>
                <!-- Sidebar navigation-->
                <nav class="">
                    <ul id="sidebarnav">
                        <!-- User Profile-->

                        <li class="sidebar-item pt-2">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#"
                                aria-expanded="false">
                                <i class="far fa-clock" aria-hidden="true"></i>
                                <span class="hide-menu"><strong style="color:#ffffff; text-decoration:underline;">CONSEILS IMPORTANTS</strong></span>
                            </a>
                            <br><br>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#"
                                aria-expanded="false">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <span class="hide-menu"><strong>│Lisez correctement</strong></span>
                            </a>
                            <br><br>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#"
                                aria-expanded="false">
                                <i class="fa fa-table" aria-hidden="true"></i>
                                <span class="hide-menu"><strong>│Répondez précisement</strong></span>
                            </a>
                            <br><br>
                        </li>

                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#"
                                aria-expanded="false">
                                <i class="fa fa-table" aria-hidden="true"></i>
                                <span class="hide-menu"><strong>│Répondez correctement</strong></span>
                            </a>
                            <br><br>
                        </li>
                    
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#"
                                aria-expanded="false">
                                <i class="fa fa-globe" aria-hidden="true"></i>
                                <span class="hide-menu"><strong>│Soyez polis et indulgeant</strong></span>
                            </a>
                            <br><br>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#"
                                aria-expanded="false">
                                <i class="fa fa-columns" aria-hidden="true"></i>
                                <span class="hide-menu"><strong>│Soyez efficace et decisif</strong></span>
                            </a>
                            <br><br>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#"
                                aria-expanded="false">
                                <i class="fa fa-info-circle" aria-hidden="true"></i>
                                <span class="hide-menu"><strong>│Apportez votre aide a tous</strong></span>
                            </a>
                            <br><br>
                        </li>
                        
                        <label for=""><strong >______________________</strong></label>

                        <br><br><br><br><br><br><br>
                        <label for=""><strong >______________________</strong></label>

                        <a class="sidebar-link waves-effect waves-dark sidebar-link" href="support.php"
                                aria-expanded="false">
                                <i class="fa fa-info-circle" aria-hidden="true"></i>
                                <span class="hide-menu"><strong class="extra" style="color:#03b8dc;" >Aide et support</strong></span>
                            </a>
                            <br><br>
                       

                        <label for=""><strong >______________________</strong></label>
                            
                            
                        
                        <br><br>
                        <label for=""><strong>&copy;Apprendre à votre rythme</strong></label>

                       
                    </ul>

                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>

      </div>