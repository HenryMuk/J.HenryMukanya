<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">    
    
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome.min.css">
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <link href="assets/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/styles1.css">
    <link rel="stylesheet" href="assets/styles2.css">
    <link href="images/logoo.png" rel="icon">
</head>