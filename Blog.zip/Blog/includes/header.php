<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700&display=swap" rel="stylesheet">
    
    
    
    
    
    
    
    
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <link href="assets/bootstrap.css" rel="stylesheet">

    <link href="assets/responsive.css" rel="stylesheet">
    <link href="assets/style.css" rel="stylesheet">
    <link href="assets/le_style.css" rel="stylesheet">
    <link href="images/logoo.png" rel="icon">
    <link href="assets/tooplate-little-fashion.css" rel="stylesheet">

    <link href="assets/mon_style.css" rel="stylesheet">
    <link href="assets/secour.css" rel="stylesheet">
    <link href="assets/secour2.css" rel="stylesheet">
    <link href="assets/secour3.css" rel="stylesheet">
    <link href="assets/secour4.css" rel="stylesheet">
    <link href="assets/resp.css" rel="stylesheet">
    
    <title>SampleCoding</title>
</head>