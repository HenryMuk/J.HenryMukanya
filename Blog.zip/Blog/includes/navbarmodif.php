
<nav class="navbar navbar-expand-lg">
                <div class="container">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                           
                            

                    <a style="text-transform: none; color:#03b8dc;" class="navbar-brand"  href="index.php">
                        <strong><span style="text-transform: none; color:#03b8dc;">Sample</span> Coding</strong>
                    </a>

                    <div class="d-lg-none">
                        <a href="sign-in.html" class="bi-person custom-icon me-3"></a>

                        <a href="product-detail.html" class="bi-bag custom-icon"></a>
                    </div>

                    <div class="responsive1" id="navbarNav">
                        <ul class="navbar-nav mx-auto">
                            

                            <li class="nav-item">
                                <a class="nav-link" href="les_questions.php">Les questions</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link active" href="">Modifier ma question</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="profile.php?id=<?= $_SESSION['id']; ?>">Mon profil</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="actions/users/deconnect.php">Déconnexion</a>
                            </li>

                            

                        </ul>
                        
                            
                       

                    </div>
                </div>
            </nav>
