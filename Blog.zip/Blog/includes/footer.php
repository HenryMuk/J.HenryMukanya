<footer class="container-fluid footer_section">
    <p class="foot">
      &copy; <span id="2023"></span> Tous droits réservés. Réalisé par
      <strong><a style="color:#03b8dc;" href="#">HenryMukanya</a></strong>
    </p>
  </footer>