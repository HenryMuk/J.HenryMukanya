<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">    
    
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome.min.css">
    <link rel="stylesheet" href="assets/styles1.css">
    <link rel="stylesheet" href="assets/styles2.css">
    <link rel="stylesheet" href="assets/styles5.css">

    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <link href="assets/bootstrap.css" rel="stylesheet">

    <link href="assets/responsive.css" rel="stylesheet">
    <link href="assets/style.css" rel="stylesheet">
    <link href="assets/styles1.css" rel="stylesheet">
    <link href="assets/le_style.css" rel="stylesheet">
    
    <link href="assets/tooplate-little-fashion.css" rel="stylesheet">

    <link href="assets/mon_style.css" rel="stylesheet">
    <link href="assets/secour.css" rel="stylesheet">
    <link href="assets/secour2.css" rel="stylesheet">
    <link href="assets/secour3.css" rel="stylesheet">
    <link href="assets/secour4.css" rel="stylesheet">
    <link href="assets/resp.css" rel="stylesheet">
    <link href="images/logoo.png" rel="icon">

     
    
  
    <link rel="stylesheet" href="assets/font-awesome.min.css">
    <link rel="stylesheet" href="assets/styles1.css">
    <link rel="stylesheet" href="assets/styles2.css">

</head>
</head>