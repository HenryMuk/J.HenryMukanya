<br><br><br><br><br>

  <section class="who_section ">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="img-box">
            <img width="50%" src="images/d-2.png" alt="">
            <img style="padding-top:10px;" width="50%" src="images/d-4.png" alt="">
          </div>
        </div>
        <div class="col-md-7">
          <div class="detail-box">
            <div class="heading_container">
              <h4 style="color:#03b8dc;">
              Notre Forum
              </h4>
            </div>
            <p style="color:#ffffff;">
              <strong>Bienvenue sur le forum d'aide aux développeurs ! SampleCoding vous présente son site</strong>
              <strong>destiné aux développeurs . Lieu d'aide où tout domaine de la programmation </strong>
              <strong>est abordé sans problème dans le but de permettre aux développeurs d'avancer dans leur divers</strong>
              <strong>projets</strong>
            </p>
            <div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <br><br><br><br><br>

  <section class="about_section layout_padding-bottom">
    <div class="container  ">
      <div class="row">
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h4 style="color:#03b8dc;">
              Les questions
              </h4>
            </div>
            <p style="color:#ffffff;">
            <strong>Sur SampleCoding , tout utilisateur a la possibilité et la liberté de poser toutes les questions souhaitées , en vue d'avancer dans son travail. Bien-sûr chaque questions posées doit être en rapport avec l'objet du site, à savoir la programmation</strong>
           </p>
            
          </div>
        </div>
        <div class="col-md-2 ">
          <div class="img-box">
            <img width="200%" src="images/s1.png" alt="">
            <img style="padding-top:10px;" width="200%" src="images/s6.png" alt="">
          </div>
        </div>

      </div>
    </div>
  </section>

  

  <br>

<section class="who_section ">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="img-box">
            <img width="50%" src="images/s4.png" alt="">
            <img style="padding-top:10px;" width="50%" src="images/s3.png" alt="">
          </div>
        </div>
        <div class="col-md-7">
          <div class="detail-box">
            <div class="heading_container">
              <h4 style="color:#03b8dc;">
                Les réponses
              </h4>
            </div>
            <p style="color:#ffffff;">
            <strong>Toutes questions posées aura une réponse selon le niveau de connaissance des autres utilisateurs du site</strong>
            <strong>Ce qui signifie que tout utilisateur est libre de non seulement poser des questions , mais aussi d'y répondre !</strong>
            <strong>Ainsi une question peut reçevoir un nombre infini de réponse dans le seul but de venir en aide à chacun</strong>
            <strong>Alors ne tardez pas <a style="color:#03b8dc; text-decoration:underline;" href="inscription.php">Inscrivez-vous !</a></strong>
            </p>
            
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>




  <br><br><br>