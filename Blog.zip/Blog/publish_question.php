<?php 
require('actions/users/security.php');
require('actions/questions/publish_question.php');
?>


<!DOCTYPE html>
<html lang="en">

<?php
    include"includes/header.php";
    include"includes/navbarpost.php";
    include"includes/navpublish.php";
?>

<body>
    
    <br><br><br><br><br><br>
    <div class="poster">
    <form class="container" method="POST">

   
    

    
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong style="color:#ffffff;">Titre de la question</strong> <strong style="color:red; font-size:25px;">*</strong></label>
            <input type="text" class="form-control" name="titre" required >
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong style="color:#ffffff;">Description de la question</strong><strong style="color:red; font-size:25px;">*</strong></label>
            <input type="text" class="form-control" name="description" required >
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong style="color:#ffffff;">Contenu de la question</strong><strong style="color:red; font-size:25px;">*</strong></label>
            <textarea type="text" class="form-control" style="height:150px;" name="contenu" required></textarea>
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong style="color:#ffffff;">Code source (facultatif)</strong></label>
            <textarea type="text" class="form-control" style="height:150px;" name="code" ></textarea>
        </div>

        <button type="submit" class="btn btn-primary" name="validate">Publier la question</button>
   </form>

   </div>
</body>
</html>

</body>
</html>