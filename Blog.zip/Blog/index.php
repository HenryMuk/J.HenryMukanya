<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="images/logoo.png" rel="icon">
    <title>SampleCoding</title>
    <style>
        *{
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            }
        body, html {
            height: 100%;
            margin: 0;
            padding: 0;
            background: rgb(184, 26, 26);
        }

        .container-fluid {
            height: 100%;
        }

        .profile-image {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            margin-right: 10px;
            background: white;
            border:3px white solid;
        }

        .bot-name {
            color: red;
            font-weight: bold;
        }

        @keyframes fade-in {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .loading {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color:  #121010;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            opacity: 1;
            transition: opacity 0.5s ease-in-out;
        }

        .loading-content {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .loading-text {
            margin-top: 20px;
            font-size: 17px;
            text-align: center;
            font-weight: bold;
        }

        .loader {
            margin-top: 10px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg);}
        }

        .loading-container {
            text-align: center;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        @media (max-width: 768px) {
            .container {
                padding: 50px 20px;
            }
        }

        @media (max-width: 480px) {
            h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="loading">
        <div class="loading-container">
            <div class="loading-content">
                <div class="loading-text">
                    <img src="images/logoo.png" class="profile-image" alt=""><br><br>
                    <span style="font-size: 13px;">SampleCoding<br>
                    Apprendre à votre rythme
                    </span>
            
            </div>
                <div class="loader"></div>
            </div>
        </div>
    </div>

    <script>
        window.addEventListener('load', function() {
            setTimeout(function() {
                window.location.href = 'index1.php';
            }, 5000);
        });
    </script>
</body>
</html>
