<?php


     require('actions/users/security.php');
     require('actions/questions/showArticleContentAction.php'); 
     require('actions/questions/postAnswerAction.php');
     require('actions/questions/showAllAnswersOfQuestionAction.php');

?>



<!DOCTYPE html>
<html lang="en">
<?php 
    include"includes/header.php";
    include"includes/navbaranswers.php"; 

?>
<body>
    
   
    <br><br><br><br><br><br>

    <div class="container">


       
                <div class="card">
                    <div class="card-header">
                    <strong><?=$question_title;?>  │ Question posée par : <img class="mon_image2" src="images/<?=$question_photo_auteur?>" alt="">   <a href="" style="color:#03b8dc; text-decoration:underline;"><?=$question_pseudo_author;?></a></strong>
                    </div>
                    <div class="card-body">
                    <label style="text-transform: none; color:#03b8dc;"><strong>Description :</strong></label><br><br><strong><?=$question_description;?></strong>
                    </div>
                    <div class="card-footer">
                    <label style="text-transform: none; color:#03b8dc;"><strong>Contenu :</strong></label><br><br><strong><?=$question_content;?></strong>
                    </div>
                    <?php if($question_code != NULL){ ?>
                    <div class="card-footer">
                        
                    <label style="text-transform: none; color:#03b8dc;"><strong>Code source :</strong></label><br><br><label for="" style="color:#585858;"><?=$question_code;?></label>
                    </div>
                    <?php
                    }
                    ?>
                
                <div>
         
                <br>
                
                <section class="show-answers">
                
                    <form class="form-group" method="POST">
                        <div class="mb-3">
                           
                            <textarea name="answer" class="form-control" style="height:100px; border-radius:1%;" placeholder="Entrer votre réponse ici"></textarea>
                            <br>
                            <button class="btn btn-primary" type="submit" name="validate" style="margin-left:10px;">Répondre</button>
                        </div>
                    </form>
                    
                    <?php 
                        while($answer = $getAllAnswersOfThisQuestion->fetch()){
                            ?>
                           
                            <div class="card" >
                            <div class="">
                                    <a href="profilvisit.php?id=<?= $answer['id_auteur']; ?>"style="color:#ffeba7; text-decoration:underline; margin-left:10px;">
                                        <img class="mon_image2" src="images/<?=$answer['photo_auteur'];?>" alt=""> <?= $answer['pseudo_auteur']; ?> a répondu :
                                    </a>
                                </div>
                                <div class="card-body">
                                    <?=$answer['contenu'];?>
                                </div>
                            </div>
                         
                            <br>
                            <?php
                        }
                    ?>

                </section>
                
               

          
                
            

    </div>

</body>
</html>