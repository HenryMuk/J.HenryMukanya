<?php  
session_start();
require('actions/questions/showAllQuestions.php');

?>

<!DOCTYPE html>
<html lang="en">
<?php
    include"includes/header.php";
    include"includes/navbarindex.php";
    include"includes/headSection.php";

?>

<body>
    <br><br><br><br><br><br><br>
   
   
           


    <?php
    include"includes/footer.php";
  
?>

</body>



</html>
