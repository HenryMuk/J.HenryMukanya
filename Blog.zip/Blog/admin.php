<?php  
session_start();
require('actions/users/securityAdmin.php');
require('actions/questions/showAllQuestions.php');

?>

<!DOCTYPE html>
<html lang="en">
<?php
    include"includes/header.php";
    include"includes/adminheader.php";
   
 
    

?>

<body>
    <br><br><br><br><br><br><br>
   
    <div class="container">
    
        <form method="GET">

            <div class="form-group row">

                <div class="col-8">
                    <input type="search" name="search" placeholder="Rechercher une question" class="form-control">
                </div>
                <div class="col-4">
                    <button class="btn btn-success" type="submit">Rechercher</button>
                </div>

            </div>
        </form>

        <br>

        <?php
            while($question = $getAllQuestions->fetch()){
        ?>

                <div class="card">
                    <div class="card-header">
                    <strong><?=$question['titre'];?></strong>
                    </div>
                    <div class="card-body">
                        <strong><?=$question['description'];?></strong>
                    </div>
                    <div class="card-footer">
                       <img class="mon_image2" src="images/<?=$question['photo_auteur'];?>" alt="">  Publié par <a href="profilvisit.php?id=<?= $question['id_auteur']; ?>"><?=$question['pseudo_auteur'];?></a> le <?=$question['date_publication'];?>    <img class="mon_image2" src="images/main.png" alt=""><a class="bouton" href="articles_for_admin.php?id=<?= $question['id']; ?>"> Accéder à la question</a>
                       <a href="actions/administration/deleteQuestionAction.php?id=<?= $question['id']; ?>" class="btn btn-danger">Supprimer la question</a>
                    </div>
                </div>
                    
                <?php
                }
                ?>
                
                <br>
           

    </div>

    

</body>



</html>
