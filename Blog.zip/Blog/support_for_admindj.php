<?php  

require('actions/administration/AllSupport.php');
require('actions/administration/deleteSupports.php');

?>

<!DOCTYPE html>
<html lang="en">
<?php
    include"includes/header.php";
    include"includes/adminheader.php";
   
 
    

?>

<body>
    <br><br><br><br><br><br><br>
   
    <div class="container">
    
        <form method="GET">

            <div class="form-group row">

                <div class="col-8">
                    <input type="search" name="search" placeholder="Rechercher une question" class="form-control">
                </div>
                <div class="col-4">
                    <button class="btn btn-success" type="submit">Rechercher</button>
                </div>

            </div>
        </form>

        <br>

        <?php
            while($support = $getAllSupports->fetch()){
        ?>

                <div class="card">
                    <div class="card-header">
                    <strong><?=$support['support_auteur'];?></strong>
                    </div>
                    <div class="card-body">
                        <strong><?=$support['support_email'];?></strong>
                    </div>
                    <div class="card-footer">
                        <strong><?=$support['content'];?></strong>
                    </div>
                    <div class="card-footer">
                       <a href="actions/administration/deleteSupports.php?id=<?= $support['id']; ?>" class="btn btn-danger">Supprimer le support</a>
                    </div>
                </div>
                    
                <?php
                }
                ?>
                
                <br>
           

    </div>

    

</body>



</html>
