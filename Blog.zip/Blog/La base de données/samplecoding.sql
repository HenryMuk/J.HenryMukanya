-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 22, 2023 at 08:54 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `samplecoding`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_auteur` int NOT NULL,
  `pseudo_auteur` varchar(255) NOT NULL,
  `id_question` int NOT NULL,
  `contenu` text NOT NULL,
  `photo_auteur` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'mon-logo.png',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `id_auteur`, `pseudo_auteur`, `id_question`, `contenu`, `photo_auteur`) VALUES
(44, 15, 'Hank', 23, 'Rien', '653555a38733f.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_auteur` int NOT NULL,
  `comment_auteur` text NOT NULL,
  `comment_email` text NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titre` text NOT NULL,
  `description` text NOT NULL,
  `contenu` text NOT NULL,
  `id_auteur` int NOT NULL,
  `pseudo_auteur` varchar(255) NOT NULL,
  `date_publication` text NOT NULL,
  `code` text NOT NULL,
  `photo_auteur` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `titre`, `description`, `contenu`, `id_auteur`, `pseudo_auteur`, `date_publication`, `code`, `photo_auteur`) VALUES
(25, 'Dernier', 'derereir', 'cecece', 22, 'Amelie', '22/10/23', '', 'user1.png'),
(24, 'Test dernier', 'Description derniere', 'efeff', 21, 'Paul', '22/10/23', 'fdfd', 'user1.png'),
(23, 'Test de principe', 'Description de principe', 'erererer', 15, 'Hank', '22/10/23', 'erere', 'mon-logo.png'),
(22, 'Problème avec mon IDE', 'Ouverture de mon IDE compliquée', 'Abcdefghijefefefefefef', 14, 'Double J', '22/10/23', '', 'mon-logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `support`
--

DROP TABLE IF EXISTS `support`;
CREATE TABLE IF NOT EXISTS `support` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_auteur` int NOT NULL,
  `support_auteur` varchar(20) NOT NULL,
  `support_email` text NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `mdp` text NOT NULL,
  `role` int NOT NULL,
  `photo` varchar(10000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'mon-logo.png',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `mdp`, `role`, `photo`) VALUES
(14, 'Double J', 'Dalton', 'jonashank366@gmail.com', '$2y$10$gI8YYI.pBscN16rWSiyBUe81YJDBgG6wymMiZ9FHYohBgOO9eYhPG', 0, '653551c3364fb.jpg'),
(20, 'Tom', 'Holyday', 'jonashank966@gmail.com', '$2y$10$zUTsIn8HmjRczSJ5qbOEceXhwOka14Q92DIy2kLo6YSosMFERPClq', 0, '653568dc8a815.jpg'),
(17, 'Henry', 'Bilonda', 'jonashank366@gmail.com', '$2y$10$BbHZi/Des0sL5KqhxOdyzetpQqSMiPiMSyd/BpBOkCd9HeUZ/Sk/a', 4, '653550c2860f4.jpg'),
(21, 'Paul', 'Pierre', 'jonashank966@gmail.com', '$2y$10$YO4M5n0dCkbMoKHh2aWyxuWqcglBPncFCHvkCnlJmTn1TMKvLN6I2', 0, 'user1.png'),
(22, 'Amelie', 'Naomie', 'jonashank966@gmail.com', '$2y$10$3m5ACu8OAOdz1fGWhrtpBuVeLA3pv2aNC7aPcpMdHDYYufzdF6Vz6', 0, 'user1.png'),
(23, 'Jacky', 'Mukanya', 'jonashank366@gmail.com', '$2y$10$G/5gRvP4tq8M/wkERzsttOLfeSYRdMoqnAULvESe/J6wv0qzzn8bu', 0, 'user1.png'),
(24, 'Zack', 'Roger', 'jonashank366@gmail.com', '$2y$10$pdG/DEu7rCKLWG/KoG/W3ub3su7SsKS/rsp5GbBSjHi9dWGfCkpve', 0, 'user1.png'),
(25, 'Bob', 'Henry', 'jonashank966@gmail.com', '$2y$10$OuNLDlsP0c0DmLNr7XnhtOzcOM.5UMKMOe.luZA9grkH3w.83tAe.', 0, 'user1.png'),
(26, 'fr', 'Bilonda', 'jonashank966@gmail.com', '$2y$10$gbEJWmbo2ZGpy5k.q6HeY./ohEQs4bO60ePiIV3T0sk4IOEaRO5Li', 0, 'user1.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
