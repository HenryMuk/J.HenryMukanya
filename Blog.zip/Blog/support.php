<?php 

require('actions/users/security.php');
require('actions/extra/supportaction.php');
?>



<!DOCTYPE html>
<html lang="en">
<?php
    include"includes/headform.php";
    include"includes/navbarsupport.php";
?>


<body>
    

<br><br><br><br>
   

    <form class="container" method="POST">


        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong>●Rencontrez-vous des problèmes liés à l'utilisation du site dans son ensemble ou d'un domaine précis?</strong></label>
            
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong>●Vous n'arrivez pas à poser vos questions où à répondre à celles des autres ?</strong></label>
            
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong>●Avez-vous des suggestions ou des propositions d'amélioration pour le site?</strong></label>
           
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><strong>Faîtes les nous savoir sans plus tarder !</strong></label>
            <textarea type="text" class="form-control" name="content" ></textarea>
        </div>

        <button type="submit" class="btn btn-primary" name="validate">Envoyer</button>
   </form>



</body>
</html>