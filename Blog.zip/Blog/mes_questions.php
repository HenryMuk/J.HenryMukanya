<?php 
    require('actions/users/security.php');
    require('actions/questions/myQuestionsAction.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<?php
    include"includes/headprofil.php";
 
    include"includes/navbarprofil.php";
?>


<body>


    <br><br><br><br><br><br>
    <div class="container">

        <?php 
        

            while($question = $getAllMyQuestions->fetch()){
                if($question == NULL)
                {
                    echo '<script>alert("Aucune question touvée");</script>';
                }
                ?>
                
                <div class="card">
                    <div class="card-header">
                       
                            <?= $question['titre']; ?>
                        
                    </div>
                    <div class="card-body">
                       
                    <label style="text-transform: none; color:#03b8dc;"><strong>Description :</strong></label><br><br><?= $question['description']; ?>
                        
                    </div>

                    <div class="card-body">
                       
                   
                        <a href="articles.php?id=<?= $question['id']; ?>" class="btn btn-primary" id="pers">Accéder à la question</a>
                        <a href="modif_question.php?id=<?= $question['id']; ?>" class="btn btn-warning" id="pers">Modifier la question</a>
                        <a href="actions/questions/deleteQuestionAction.php?id=<?= $question['id']; ?>" class="btn btn-danger" id="pers">Supprimer la question</a>
                    </div>
                </div>
       
                <br>
                <?php
            }

        ?>

    </div>

</body>
</html>