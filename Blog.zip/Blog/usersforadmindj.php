<?php  


require('actions/administration/AllUsers.php');
require('actions/administration/deleteUsersAction.php');
?>

<!DOCTYPE html>
<html lang="en">
<?php
   include"includes/headprofil.php";
   include"includes/adminheader.php";
?>

<body>
    

<br><br><br><br><br><br><br>

<div class="section">
		<div class="container">

        <form method="GET">

<div class="form-group row">

    <div class="col-8">
        <input type="search" name="search" placeholder="Rechercher une question" class="form-control">
    </div>
    <div class="col-4">
        <button class="btn btn-success" type="submit">Rechercher</button>
    </div>

                </div>
        </form>


                            
			
								
                                        <?php 

                                            while($user = $getAllUsers->fetch()){ 

                                                if($user['role'] <= 3){ 

                                                    $role = "Membre";	
                                                }
                                                else if($user['role'] >= 4)
                                                {
                                                    $role = "Administrateur";	
                                                }

                                        ?>
											
										<form method="POST" action="">

											<div class="upload">
												<img src="images/<?=$user['photo'];?>" alt="" id="image">
													

													



											</div>
											<div class="form-group">
												<label class="form-style" > <?=$user['username'];?></label>
												<i class="input-icon uil uil-user"></i>
											</div>	
											<div class="form-group mt-2">
												<label class="form-style" > <?=$user['name'];?></label>
												<i class="input-icon uil uil-user"></i>
											</div>	
                      						<div class="form-group mt-2">
												<label class="form-style" > <?=$user['email'];?></label>
												<i class="input-icon uil uil-at"></i>
											</div>
                                            <div class="form-group mt-2">
												<label class="form-style" > <?=$role?></label>
												<i class="input-icon uil uil-at"></i>
											</div>
                                            <div class="form-group mt-2">
												<label class="form-style" > <?=$user['description'];?></label>
												<i class="input-icon uil uil-at"></i>
											</div>

                                            <br>
                                            <br>
											
                                            
                                            
                                            <a  href="actions/administration/deleteUsersAction.php?id=<?= $user['id']; ?>" class="btn btn-danger" >Supprimer l'utilisateur </a>
										<br>
                                        <br>	
                                        
                                        
                                        
                                        </form>

                                            <?php
                                            }
                                            ?>


</div>
</div>








</body>
</html>

</body>



</html>
