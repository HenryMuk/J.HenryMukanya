<?php require('actions/users/signin.php');?>


<!doctype html>
<?php  
    include"includes/headConnect.php";
?>
<html lang="en">
<body>

<div class="section">
		<div class="container">
			<div class="row full-height justify-content-center">
				<div class="col-12 text-center align-self-center py-5">
					<div class="section pb-5 pt-5 pt-sm-2 text-center">
						<h6 class="mb-0 pb-3"><span>Inscription </span></h6>
			          	<input class="checkbox" type="checkbox" id="reg-log" name="reg-log"/>
			          	<label for="reg-log"></label>
						<div class="card-3d-wrap mx-auto">
							<div class="card-3d-wrapper">
								<div class="card-front" style="height:530px;">
									<div class="center-wrap">
										<div class="section text-center">
											<h4 class="mb-4 pb-3">Inscription</h4>
										<form method="POST" action="">

											
											<div class="form-group">
												<input type="text" class="form-style" placeholder="Username" name="username" required>
												<i class="input-icon uil uil-user"></i>
											</div>	
											<div class="form-group mt-2">
												<input type="tel" class="form-style" placeholder="Name" name="name" required> 
												<i class="input-icon uil uil-user"></i>
											</div>	
                      						<div class="form-group mt-2">
												<input type="email" class="form-style" placeholder="Email" name="email" required>
												<i class="input-icon uil uil-at"></i>
											</div>
											<div class="form-group mt-2">
												<input type="password" class="form-style" placeholder="Password" name="mdp" required>
												<i class="input-icon uil uil-lock-alt"></i>
												<label for="" style="font-size:12px;">caractéristiques du mot de passe</label> <br>
												<li style="font-size:12px;">Minimum une lettre majuscule</li>
												<li style="font-size:12px;">Minimum un chiffre</li>
												<li style="font-size:12px;">Minimum 8 caractères</li>
												

											</div>
											<input type="submit" name="validate" class="btn mt-4" value="S'inscrire">
											<a style="color:#ffffff; text-decoration:underline;" href="connexion.php"><p>J'ai un compte, me connecter</p></a>

										</form>
	





                                        </div>
			      					</div>
			      				</div>
			      			</div>
			      		</div>
			      	</div>
		      	</div>
	      	</div>
	    </div>
	</div>

</body>
</html>